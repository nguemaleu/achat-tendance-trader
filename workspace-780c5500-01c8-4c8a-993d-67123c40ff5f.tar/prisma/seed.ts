import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

async function main() {
  // Create demo user
  const user = await prisma.user.upsert({
    where: { email: 'demo@achat-tendance.com' },
    update: {},
    create: {
      email: 'demo@achat-tendance.com',
      name: 'Trader Demo',
      isDemo: true,
    },
  });

  // Create settings
  await prisma.userSettings.upsert({
    where: { userId: user.id },
    update: {},
    create: {
      userId: user.id,
      initialCapital: 10000,
      currentCapital: 10847.50,
      accountCurrency: 'USD',
      maxRiskPerTrade: 1.0,
      dailyLossLimit: 3.0,
      maxTradesPerDay: 5,
      favoriteAssets: 'XAU/USD,EUR/USD,GBP/USD,NASDAQ',
      favoriteSessions: 'Londres,New York',
      favoriteTimeframes: 'H4,H1,M15',
      monthlyGoal: 500,
      darkMode: true,
    },
  });

  // Create demo opportunities
  const opp1 = await prisma.opportunity.create({
    data: {
      userId: user.id,
      name: 'XAU/USD Retour sur support 2630',
      asset: 'XAU/USD',
      marketCategory: 'Métaux précieux',
      tradingSession: 'Londres',
      primaryTimeframe: 'H4',
      entryTimeframe: 'M15',
      trendH4: 'Haussière',
      trendH1: 'Haussière',
      currentPrice: 2642.50,
      mainSupport: 2630.00,
      mainResistance: 2675.00,
      plannedEntry: 2632.00,
      plannedStopLoss: 2622.00,
      takeProfit1: 2652.00,
      takeProfit2: 2672.00,
      riskRewardRatio: 2.0,
      validationScore: 9,
      checklistJson: JSON.stringify({
        c1: true, c2: true, c3: true, c4: true, c5: true,
        c6: true, c7: true, c8: true, c9: true, c10: true, c11: false
      }),
      status: 'Position ouverte',
      comments: 'Belle configuration sur XAU avec retour sur l\'ancienne résistance devenue support.',
    },
  });

  const opp2 = await prisma.opportunity.create({
    data: {
      userId: user.id,
      name: 'EUR/USD Test zone 1.0850',
      asset: 'EUR/USD',
      marketCategory: 'Devise',
      tradingSession: 'Londres',
      primaryTimeframe: 'H4',
      entryTimeframe: 'H1',
      trendH4: 'Haussière',
      trendH1: 'Neutre',
      currentPrice: 1.0872,
      mainSupport: 1.0850,
      mainResistance: 1.0920,
      plannedEntry: 1.0852,
      plannedStopLoss: 1.0832,
      takeProfit1: 1.0892,
      takeProfit2: 1.0920,
      riskRewardRatio: 2.0,
      validationScore: 7,
      checklistJson: JSON.stringify({
        c1: true, c2: true, c3: false, c4: true, c5: true,
        c6: true, c7: true, c8: true, c9: false, c10: true, c11: true
      }),
      status: 'Prêt à entrer',
      comments: 'Attendre confirmation bougie H1.',
    },
  });

  const opp3 = await prisma.opportunity.create({
    data: {
      userId: user.id,
      name: 'GBP/USD Cassure résistance',
      asset: 'GBP/USD',
      marketCategory: 'Devise',
      tradingSession: 'New York',
      primaryTimeframe: 'H4',
      entryTimeframe: 'M15',
      trendH4: 'Haussière',
      trendH1: 'Haussière',
      currentPrice: 1.2745,
      mainSupport: 1.2710,
      mainResistance: 1.2780,
      plannedEntry: 1.2748,
      plannedStopLoss: 1.2720,
      takeProfit1: 1.2780,
      takeProfit2: 1.2810,
      riskRewardRatio: 2.0,
      validationScore: 8,
      status: 'Terminé',
      comments: 'Trade exécuté et clôturé en gain.',
    },
  });

  const opp4 = await prisma.opportunity.create({
    data: {
      userId: user.id,
      name: 'XAU/USD Structure baissière H4',
      asset: 'XAU/USD',
      marketCategory: 'Métaux précieux',
      tradingSession: 'Asie',
      primaryTimeframe: 'H4',
      entryTimeframe: 'H1',
      trendH4: 'Baissière',
      trendH1: 'Baissière',
      currentPrice: 2615.00,
      mainSupport: 2600.00,
      mainResistance: 2630.00,
      plannedEntry: 2618.00,
      plannedStopLoss: 2630.00,
      takeProfit1: 2598.00,
      takeProfit2: 2580.00,
      riskRewardRatio: 1.5,
      validationScore: 3,
      status: 'Annulé',
      comments: 'Annulé car tendance baissière, pas d\'achat.',
    },
  });

  const opp5 = await prisma.opportunity.create({
    data: {
      userId: user.id,
      name: 'NASDAQ Rechute sur support 19500',
      asset: 'NASDAQ',
      marketCategory: 'Indice',
      tradingSession: 'New York',
      primaryTimeframe: 'H4',
      entryTimeframe: 'M15',
      trendH4: 'Haussière',
      trendH1: 'Neutre',
      currentPrice: 19520.00,
      mainSupport: 19500.00,
      mainResistance: 19680.00,
      plannedEntry: 19505.00,
      plannedStopLoss: 19460.00,
      takeProfit1: 19590.00,
      takeProfit2: 19680.00,
      riskRewardRatio: 1.93,
      validationScore: 6,
      status: 'A surveiller',
      comments: 'Ratio inférieur à 2:1, à surveiller uniquement.',
    },
  });

  // Create demo trades
  const now = new Date();
  const tradesData = [
    {
      userId: user.id, opportunityId: opp3.id,
      asset: 'GBP/USD', direction: 'ACHAT',
      entryDate: new Date(now.getTime() - 6 * 86400000),
      exitDate: new Date(now.getTime() - 6 * 86400000 + 3 * 3600000),
      entryPrice: 1.2748, initialStopLoss: 1.2720, takeProfit1: 1.2780, takeProfit2: 1.2810,
      exitPrice: 1.2805, lotSize: 0.18, capitalBefore: 10420.00, riskPercent: 0.5, riskAmount: 52.10,
      grossResult: 102.60, fees: 3.50, netResult: 99.10, resultR: 1.9,
      status: 'Fermé en gain', planRespected: true,
      emotionBefore: 'Concentré', emotionAfter: 'Calme',
      mainError: '', lessonLearned: 'Patience sur l\'entrée a payé.',
    },
    {
      userId: user.id, opportunityId: null,
      asset: 'XAU/USD', direction: 'ACHAT',
      entryDate: new Date(now.getTime() - 5 * 86400000),
      exitDate: new Date(now.getTime() - 5 * 86400000 + 2 * 3600000),
      entryPrice: 2618.50, initialStopLoss: 2608.00, takeProfit1: 2638.00, takeProfit2: 2658.00,
      exitPrice: 2635.00, lotSize: 0.05, capitalBefore: 10519.10, riskPercent: 0.5, riskAmount: 52.60,
      grossResult: 82.50, fees: 4.20, netResult: 78.30, resultR: 1.49,
      status: 'Fermé en gain', planRespected: true,
      emotionBefore: 'Calme', emotionAfter: 'Concentré',
      mainError: '', lessonLearned: 'Bon respect du plan.',
    },
    {
      userId: user.id, opportunityId: null,
      asset: 'EUR/USD', direction: 'ACHAT',
      entryDate: new Date(now.getTime() - 4 * 86400000),
      exitDate: new Date(now.getTime() - 4 * 86400000 + 1.5 * 3600000),
      entryPrice: 1.0865, initialStopLoss: 1.0845, takeProfit1: 1.0905, takeProfit2: 1.0925,
      exitPrice: 1.0842, lotSize: 0.26, capitalBefore: 10597.40, riskPercent: 0.5, riskAmount: 52.99,
      grossResult: -59.80, fees: 3.80, netResult: -63.60, resultR: -1.2,
      status: 'Fermé en perte', planRespected: false,
      emotionBefore: 'Impatient', emotionAfter: 'Frustré',
      mainError: 'Entrée trop tôt', lessonLearned: 'Attendre la confirmation avant d\'entrer.',
    },
    {
      userId: user.id, opportunityId: null,
      asset: 'XAU/USD', direction: 'ACHAT',
      entryDate: new Date(now.getTime() - 3 * 86400000),
      exitDate: new Date(now.getTime() - 3 * 86400000 + 4 * 3600000),
      entryPrice: 2625.00, initialStopLoss: 2615.00, takeProfit1: 2645.00, takeProfit2: 2665.00,
      exitPrice: 2648.30, lotSize: 0.05, capitalBefore: 10533.80, riskPercent: 0.5, riskAmount: 52.67,
      grossResult: 116.50, fees: 4.20, netResult: 112.30, resultR: 2.13,
      status: 'Fermé en gain', planRespected: true,
      emotionBefore: 'Calme', emotionAfter: 'Calme',
      mainError: '', lessonLearned: 'Exécution parfaite du plan.',
    },
    {
      userId: user.id, opportunityId: null,
      asset: 'GBP/USD', direction: 'ACHAT',
      entryDate: new Date(now.getTime() - 2 * 86400000),
      exitDate: new Date(now.getTime() - 2 * 86400000 + 2 * 3600000),
      entryPrice: 1.2795, initialStopLoss: 1.2770, takeProfit1: 1.2830, takeProfit2: 1.2860,
      exitPrice: 1.2768, lotSize: 0.18, capitalBefore: 10646.10, riskPercent: 0.5, riskAmount: 53.23,
      grossResult: -48.60, fees: 3.50, netResult: -52.10, resultR: -0.98,
      status: 'Fermé en perte', planRespected: true,
      emotionBefore: 'Calme', emotionAfter: 'Concentré',
      mainError: '', lessonLearned: 'Perte normale, stop respecté. Le marché n\'était pas prêt.',
    },
    {
      userId: user.id, opportunityId: opp1.id,
      asset: 'XAU/USD', direction: 'ACHAT',
      entryDate: new Date(now.getTime() - 1 * 86400000),
      entryPrice: 2632.50, initialStopLoss: 2622.00, takeProfit1: 2652.00, takeProfit2: 2672.00,
      lotSize: 0.05, capitalBefore: 10594.00, riskPercent: 0.5, riskAmount: 52.97,
      status: 'Ouvert', planRespected: null,
      emotionBefore: 'Concentré', emotionAfter: '',
      mainError: '', lessonLearned: '',
    },
  ];

  for (const t of tradesData) {
    await prisma.trade.create({ data: t });
  }

  // Create daily journals
  const journals = [
    {
      userId: user.id,
      date: new Date(now.getTime() - 6 * 86400000),
      startBalance: 10420.00, endBalance: 10519.10, dailyResult: 99.10,
      tradeCount: 1, winCount: 1, lossCount: 0,
      planRespected: true, emotionalState: 'Calme', concentrationLevel: 'Élevé',
      mainError: '', bestPoint: 'Patience sur l\'entrée GBP/USD',
      correction: 'Continuer ainsi', stoppedAfterTwoLosses: false,
      generalComment: 'Bonne journée de trading.',
    },
    {
      userId: user.id,
      date: new Date(now.getTime() - 5 * 86400000),
      startBalance: 10519.10, endBalance: 10597.40, dailyResult: 78.30,
      tradeCount: 1, winCount: 1, lossCount: 0,
      planRespected: true, emotionalState: 'Concentré', concentrationLevel: 'Élevé',
      mainError: '', bestPoint: 'Bon respect du plan sur XAU',
      correction: '', stoppedAfterTwoLosses: false,
      generalComment: 'Solide.',
    },
    {
      userId: user.id,
      date: new Date(now.getTime() - 4 * 86400000),
      startBalance: 10597.40, endBalance: 10533.80, dailyResult: -63.60,
      tradeCount: 1, winCount: 0, lossCount: 1,
      planRespected: false, emotionalState: 'Impatient', concentrationLevel: 'Moyen',
      mainError: 'Entrée trop tôt', bestPoint: 'Aucun',
      correction: 'Toujours attendre la clôture de la bougie de confirmation', stoppedAfterTwoLosses: false,
      generalComment: 'Mauvaise journée, entrée impulsive sur EUR/USD.',
    },
    {
      userId: user.id,
      date: new Date(now.getTime() - 3 * 86400000),
      startBalance: 10533.80, endBalance: 10646.10, dailyResult: 112.30,
      tradeCount: 1, winCount: 1, lossCount: 0,
      planRespected: true, emotionalState: 'Calme', concentrationLevel: 'Élevé',
      mainError: '', bestPoint: 'Exécution parfaite XAU/USD',
      correction: '', stoppedAfterTwoLosses: false,
      generalComment: 'Excellente journée, retour à la discipline.',
    },
    {
      userId: user.id,
      date: new Date(now.getTime() - 2 * 86400000),
      startBalance: 10646.10, endBalance: 10594.00, dailyResult: -52.10,
      tradeCount: 1, winCount: 0, lossCount: 1,
      planRespected: true, emotionalState: 'Calme', concentrationLevel: 'Élevé',
      mainError: '', bestPoint: 'Stop respecté sans émotion',
      correction: '', stoppedAfterTwoLosses: false,
      generalComment: 'Perte normale, le stop a bien fonctionné.',
    },
  ];

  for (const j of journals) {
    await prisma.dailyJournal.create({ data: j });
  }

  // Create alerts
  const alerts = [
    { userId: user.id, type: 'opportunite', message: 'EUR/USD est prêt à être vérifié (score 7)', relatedEntityType: 'opportunity', relatedEntityId: opp2.id },
    { userId: user.id, type: 'risque', message: 'Le ratio de NASDAQ est inférieur à 2:1 (1.93)', relatedEntityType: 'opportunity', relatedEntityId: opp5.id },
    { userId: user.id, type: 'journal', message: 'Journal quotidien non complété pour aujourd\'hui' },
  ];
  for (const a of alerts) {
    await prisma.alert.create({ data: a });
  }

  console.log('Demo data seeded successfully!');
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });
