'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertTriangle, Info } from 'lucide-react';

const ASSETS_POINT_VALUES: Record<string, number> = {
  'XAU/USD': 1,
  'EUR/USD': 10,
  'GBP/USD': 10,
  'USD/JPY': 1000,
  'USD/CAD': 10,
  'AUD/USD': 10,
  'NASDAQ': 1,
  'S&P 500': 1,
  'DAX': 1,
};

interface RiskCalculatorPanelProps {
  capital?: number;
  entryPrice?: string;
  stopLoss?: string;
  takeProfit1?: string;
  takeProfit2?: string;
  asset?: string;
  embedded?: boolean;
}

export function RiskCalculatorPanel({ capital: initCapital = 10000, entryPrice: initEntry = '', stopLoss: initSl = '', takeProfit1: initTp1 = '', takeProfit2: initTp2 = '', asset: initAsset = 'XAU/USD', embedded }: RiskCalculatorPanelProps) {
  const [capital, setCapital] = useState(initCapital);
  const [riskPercent, setRiskPercent] = useState(0.5);
  const [asset, setAsset] = useState(initAsset);
  const [entryPrice, setEntryPrice] = useState(initEntry);
  const [stopLoss, setStopLoss] = useState(initSl);
  const [tp1, setTp1] = useState(initTp1);
  const [tp2, setTp2] = useState(initTp2);
  const [pointValue, setPointValue] = useState(ASSETS_POINT_VALUES[initAsset] || 1);

  useEffect(() => { setAsset(initAsset); setPointValue(ASSETS_POINT_VALUES[initAsset] || 1); }, [initAsset]);
  useEffect(() => { setEntryPrice(initEntry); }, [initEntry]);
  useEffect(() => { setStopLoss(initSl); }, [initSl]);
  useEffect(() => { setTp1(initTp1); }, [initTp1]);
  useEffect(() => { setTp2(initTp2); }, [initTp2]);
  useEffect(() => { setCapital(initCapital); }, [initCapital]);

  const riskAmount = capital * (riskPercent / 100);
  const entry = parseFloat(entryPrice) || 0;
  const sl = parseFloat(stopLoss) || 0;
  const tp1Val = parseFloat(tp1) || 0;
  const tp2Val = parseFloat(tp2) || 0;
  const stopDistance = entry && sl ? Math.abs(entry - sl) : 0;
  const positionSize = stopDistance > 0 && pointValue > 0 ? riskAmount / (stopDistance * pointValue) : 0;
  const potentialGain = entry && tp1Val ? Math.abs(tp1Val - entry) * positionSize * pointValue : 0;
  const rr = stopDistance > 0 && potentialGain > 0 ? potentialGain / riskAmount : 0;

  const warnings: string[] = [];
  if (riskPercent > 1) warnings.push('Le risque dépasse 1% du capital.');
  if (rr > 0 && rr < 2) warnings.push('Le ratio rendement/risque est inférieur à 2:1.');
  if (positionSize > 1) warnings.push('La taille de position semble élevée.');
  if (!stopLoss) warnings.push('Le stop-loss est absent.');
  if (!tp1) warnings.push('Le Take Profit est absent.');

  return (
    <Card className={!embedded ? '' : 'border-emerald-500/30'}>
      <CardHeader className="pb-2">
        <CardTitle className="text-base flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-500" />
          Calculateur de risque
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div><Label>Capital du compte ($)</Label><Input type="number" value={capital} onChange={e => setCapital(parseFloat(e.target.value) || 0)} /></div>
          <div><Label>Risque par trade (%)</Label><Input type="number" step="0.1" min="0.1" max="5" value={riskPercent} onChange={e => setRiskPercent(parseFloat(e.target.value) || 0)} /></div>
          <div><Label>Actif</Label>
            <Input value={asset} onChange={e => { setAsset(e.target.value); setPointValue(ASSETS_POINT_VALUES[e.target.value] || 1); }} />
          </div>
          <div><Label>Prix d'entrée</Label><Input type="number" step="any" value={entryPrice} onChange={e => setEntryPrice(e.target.value)} /></div>
          <div><Label>Prix du stop-loss</Label><Input type="number" step="any" value={stopLoss} onChange={e => setStopLoss(e.target.value)} /></div>
          <div><Label>Valeur du point</Label><Input type="number" step="any" value={pointValue} onChange={e => setPointValue(parseFloat(e.target.value) || 0)} /></div>
          <div><Label>Take Profit 1</Label><Input type="number" step="any" value={tp1} onChange={e => setTp1(e.target.value)} /></div>
          <div><Label>Take Profit 2</Label><Input type="number" step="any" value={tp2} onChange={e => setTp2(e.target.value)} /></div>
        </div>

        {/* Results */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
          <div className="p-3 rounded-lg bg-accent/50"><p className="text-xs text-muted-foreground">Montant à risquer</p><p className="text-lg font-bold">${riskAmount.toFixed(2)}</p></div>
          <div className="p-3 rounded-lg bg-accent/50"><p className="text-xs text-muted-foreground">Distance du stop</p><p className="text-lg font-bold">{stopDistance > 0 ? stopDistance.toFixed(1) : '-'}</p></div>
          <div className="p-3 rounded-lg bg-accent/50"><p className="text-xs text-muted-foreground">Taille estimée</p><p className="text-lg font-bold">{positionSize > 0 ? positionSize.toFixed(2) : '-'}</p></div>
          <div className="p-3 rounded-lg bg-accent/50"><p className="text-xs text-muted-foreground">Gain potentiel (TP1)</p><p className={`text-lg font-bold ${potentialGain > 0 ? 'text-emerald-500' : ''}`}>{potentialGain > 0 ? `$${potentialGain.toFixed(2)}` : '-'}</p></div>
          <div className={`p-3 rounded-lg ${rr >= 2 ? 'bg-emerald-500/10' : rr > 0 ? 'bg-red-500/10' : 'bg-accent/50'}`}><p className="text-xs text-muted-foreground">Ratio R/R</p><p className={`text-lg font-bold ${rr >= 2 ? 'text-emerald-500' : rr > 0 ? 'text-red-500' : ''}`}>{rr > 0 ? `${rr.toFixed(2)}:1` : '-'}</p></div>
          <div className="p-3 rounded-lg bg-accent/50"><p className="text-xs text-muted-foreground">Gain TP2</p><p className="text-lg font-bold">{entry && tp2Val ? `$${(Math.abs(tp2Val - entry) * positionSize * pointValue).toFixed(2)}` : '-'}</p></div>
        </div>

        {/* Warnings */}
        {warnings.length > 0 && (
          <div className="space-y-2">
            {warnings.map((w, i) => (
              <Alert key={i} variant="destructive"><AlertTriangle className="w-4 h-4" /><AlertDescription>{w}</AlertDescription></Alert>
            ))}
          </div>
        )}

        <div className="flex items-start gap-2 p-2 rounded bg-blue-500/10 border border-blue-500/20">
          <Info className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
          <p className="text-xs text-blue-500/80">La taille de position calculée est une estimation. Vérifiez avec les spécifications du symbole dans MT4 ou MT5.</p>
        </div>
      </CardContent>
    </Card>
  );
}
