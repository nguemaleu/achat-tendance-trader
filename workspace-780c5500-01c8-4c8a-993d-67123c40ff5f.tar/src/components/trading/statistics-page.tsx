'use client';

import { useEffect, useState } from 'react';
import { useAppStore, apiHeaders } from '@/store/app-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, ReferenceLine,
} from 'recharts';
import { TrendingUp, Target, DollarSign, AlertTriangle, Award, Zap } from 'lucide-react';

interface Stats {
  currentCapital: number; totalTrades: number; winCount: number; lossCount: number;
  winRate: number; netProfit: number; avgWin: number; avgLoss: number; avgTrade: number;
  profitFactor: number; expectancy: number; maxDrawdown: number;
  bestTrade: number; worstTrade: number; gainLossRatio: number;
  planRate: number; assetPerf: Record<string, { trades: number; wins: number; pnl: number }>;
  errorCosts: Record<string, number>;
}

const COLORS = ['#10b981', '#f59e0b', '#ef4444', '#3b82f6', '#8b5cf6', '#ec4899', '#06b6d4'];

export function StatisticsPage() {
  const { demoUserId } = useAppStore();
  const [stats, setStats] = useState<Stats | null>(null);
  const [period, setPeriod] = useState('all');

  useEffect(() => {
    if (!demoUserId) return;
    let cancelled = false;
    (async () => {
      const res = await fetch('/api/stats', { headers: apiHeaders(demoUserId) });
      if (!cancelled) setStats(await res.json());
    })();
    return () => { cancelled = true; };
  }, [demoUserId]);

  if (!stats) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin w-8 h-8 border-2 border-emerald-500 border-t-transparent rounded-full" />
      </div>
    );
  }

  const assetData = Object.entries(stats.assetPerf || {}).map(([name, d], i) => ({
    name,
    trades: d.trades,
    wins: d.wins,
    pnl: Math.round(d.pnl * 100) / 100,
    fill: COLORS[i % COLORS.length],
  }));

  const errorData = Object.entries(stats.errorCosts || {}).map(([name, cost]) => ({
    name,
    cost: Math.round(cost * 100) / 100,
  })).sort((a, b) => b.cost - a.cost);

  const pieData = [
    { name: 'Gains', value: stats.winCount, fill: '#10b981' },
    { name: 'Pertes', value: stats.lossCount, fill: '#ef4444' },
  ];

  const metrics = [
    { label: 'Taux de réussite', value: `${stats.winRate}%`, icon: Target, color: stats.winRate >= 50 ? 'text-emerald-500' : 'text-red-500' },
    { label: 'Profit Factor', value: stats.profitFactor === 999 ? '∞' : stats.profitFactor.toFixed(2), icon: Award, color: 'text-emerald-500' },
    { label: 'Espérance math.', value: `$${stats.expectancy.toFixed(2)}`, icon: Zap, color: stats.expectancy > 0 ? 'text-emerald-500' : 'text-red-500' },
    { label: 'Drawdown max', value: `$${stats.maxDrawdown.toFixed(2)}`, icon: AlertTriangle, color: 'text-amber-500' },
    { label: 'Gain moyen', value: `$${stats.avgWin.toFixed(2)}`, icon: TrendingUp, color: 'text-emerald-500' },
    { label: 'Perte moyenne', value: `$${stats.avgLoss.toFixed(2)}`, icon: DollarSign, color: 'text-red-500' },
    { label: 'Meilleur trade', value: `$${stats.bestTrade.toFixed(2)}`, icon: TrendingUp, color: 'text-emerald-500' },
    { label: 'Pire trade', value: `$${stats.worstTrade.toFixed(2)}`, icon: TrendingUp, color: 'text-red-500' },
    { label: 'Ratio gain/perte', value: `${stats.gainLossRatio.toFixed(2)}`, icon: Target, color: 'text-emerald-500' },
    { label: 'Respect du plan', value: `${stats.planRate}%`, icon: Award, color: 'text-emerald-500' },
  ];

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl font-bold">Statistiques</h2>
          <p className="text-muted-foreground text-sm mt-1">Analyse détaillée de vos performances</p>
        </div>
        <Select value={period} onValueChange={setPeriod}>
          <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tout</SelectItem>
            <SelectItem value="month">Ce mois</SelectItem>
            <SelectItem value="week">Cette semaine</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Metrics grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
        {metrics.map(m => {
          const Icon = m.icon;
          return (
            <Card key={m.label} className="p-3">
              <div className="flex items-center gap-1.5 mb-1">
                <Icon className={`w-3.5 h-3.5 ${m.color}`} />
                <span className="text-[10px] text-muted-foreground truncate">{m.label}</span>
              </div>
              <p className={`text-lg font-bold ${m.color}`}>{m.value}</p>
            </Card>
          );
        })}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Win/Loss Pie */}
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Gains vs Pertes</CardTitle></CardHeader>
          <CardContent>
            <div className="h-52 flex items-center justify-center">
              {stats.totalTrades > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={pieData} cx="50%" cy="50%" innerRadius={50} outerRadius={80} dataKey="value" stroke="none">
                      {pieData.map((d, i) => <Cell key={i} fill={d.fill} />)}
                    </Pie>
                    <Tooltip contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 8, fontSize: 12 }} />
                  </PieChart>
                </ResponsiveContainer>
              ) : <p className="text-muted-foreground text-sm">Aucune donnée</p>}
            </div>
          </CardContent>
        </Card>

        {/* Per-asset performance */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Performance par actif</CardTitle></CardHeader>
          <CardContent>
            <div className="h-52">
              {assetData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={assetData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="name" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
                    <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
                    <Tooltip contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 8, fontSize: 12 }} formatter={(v: number) => [`$${v.toFixed(2)}`, 'P&L']} />
                    <ReferenceLine y={0} stroke="hsl(var(--muted-foreground))" />
                    <Bar dataKey="pnl" radius={[4, 4, 0, 0]}>
                      {assetData.map((d, i) => <Cell key={i} fill={d.pnl >= 0 ? '#10b981' : '#ef4444'} />)}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              ) : <div className="flex items-center justify-center h-full text-muted-foreground text-sm">Aucune donnée</div>}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Error costs table */}
      {errorData.length > 0 && (
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Erreurs les plus coûteuses</CardTitle></CardHeader>
          <CardContent>
            <div className="space-y-2">
              {errorData.map((e, i) => (
                <div key={i} className="flex items-center justify-between p-2 rounded bg-accent/50">
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground w-5">#{i + 1}</span>
                    <span className="text-sm">{e.name}</span>
                  </div>
                  <Badge variant="destructive">-${e.cost.toFixed(2)}</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Auto-identified insights */}
      <Card>
        <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Analyses automatiques</CardTitle></CardHeader>
        <CardContent className="space-y-2">
          {assetData.length > 0 && (
            <div className="flex items-center gap-2 p-2 rounded bg-emerald-500/10 text-sm">
              <TrendingUp className="w-4 h-4 text-emerald-500" />
              <span>Actif le plus rentable: <strong>{assetData.sort((a, b) => b.pnl - a.pnl)[0].name}</strong> (${assetData.sort((a, b) => b.pnl - a.pnl)[0].pnl >= 0 ? '+' : ''}{assetData.sort((a, b) => b.pnl - a.pnl)[0].pnl.toFixed(2)})</span>
            </div>
          )}
          {stats.planRate < 100 && (
            <div className="flex items-center gap-2 p-2 rounded bg-amber-500/10 text-sm">
              <AlertTriangle className="w-4 h-4 text-amber-500" />
              <span>Le plan est respecté dans {stats.planRate}% des cas. L'amélioration de la discipline pourrait significativement améliorer vos résultats.</span>
            </div>
          )}
          {stats.winRate >= 50 && stats.profitFactor > 1 && (
            <div className="flex items-center gap-2 p-2 rounded bg-emerald-500/10 text-sm">
              <Award className="w-4 h-4 text-emerald-500" />
              <span>Votre stratégie est globalement rentable avec un profit factor de {stats.profitFactor === 999 ? '∞' : stats.profitFactor.toFixed(2)}. Continuez à suivre votre plan.</span>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}