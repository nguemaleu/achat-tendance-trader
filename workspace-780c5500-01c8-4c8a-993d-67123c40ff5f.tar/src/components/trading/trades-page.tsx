'use client';

import { useEffect, useState } from 'react';
import { useAppStore, apiHeaders } from '@/store/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Eye, Edit, Trash2, Download, ArrowUpDown } from 'lucide-react';
import { toast } from 'sonner';

const ASSETS = ['XAU/USD', 'EUR/USD', 'GBP/USD', 'NASDAQ', 'USD/JPY', 'USD/CAD', 'AUD/USD'];
const STATUSES = ['Planifié', 'Ouvert', 'Partiellement fermé', 'Fermé en gain', 'Fermé en perte', 'Fermé à l\'équilibre', 'Annulé'];
const EMOTIONS = ['Calme', 'Concentré', 'Impatient', 'Stressé', 'Fatigué', 'Frustré', 'Trop confiant', 'En recherche de revanche'];
const ERRORS = ['Entrée trop tôt', 'Achat contre la tendance', 'Absence de confirmation', 'Stop trop serré', 'Stop déplacé', 'Position trop grande', 'Surtrading', 'Entrée pendant une annonce', 'Trade de revanche', 'Objectif irréaliste', 'Non-respect du ratio rendement/risque'];

const STATUS_COLORS: Record<string, string> = {
  'Planifié': 'bg-slate-500', 'Ouvert': 'bg-blue-500', 'Partiellement fermé': 'bg-amber-500',
  'Fermé en gain': 'bg-emerald-500', 'Fermé en perte': 'bg-red-500', 'Fermé à l\'équilibre': 'bg-gray-500', 'Annulé': 'bg-gray-600',
};

interface Trade {
  id: string; opportunityId: string | null; asset: string; direction: string;
  entryDate: string | null; exitDate: string | null; entryPrice: number | null;
  initialStopLoss: number | null; takeProfit1: number | null; takeProfit2: number | null;
  exitPrice: number | null; lotSize: number | null; capitalBefore: number | null;
  riskPercent: number | null; riskAmount: number | null; grossResult: number | null;
  fees: number; netResult: number | null; resultR: number | null;
  status: string; planRespected: boolean | null; emotionBefore: string;
  emotionAfter: string; mainError: string; lessonLearned: string;
}

const emptyTrade: Partial<Trade> = {
  asset: 'XAU/USD', direction: 'ACHAT', status: 'Planifié', fees: 0, emotionBefore: 'Calme',
};

export function TradesPage() {
  const { demoUserId } = useAppStore();
  const [trades, setTrades] = useState<Trade[]>([]);
  const [filterStatus, setFilterStatus] = useState('all');
  const [search, setSearch] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Partial<Trade> | null>(null);
  const [viewing, setViewing] = useState<Trade | null>(null);
  const [sortField, setSortField] = useState<string>('entryDate');
  const [sortAsc, setSortAsc] = useState(false);

  async function reload() {
    if (!demoUserId) return;
    const h = apiHeaders(demoUserId);
    const res = await fetch('/api/trades', { headers: h });
    setTrades(await res.json());
  }

  useEffect(() => {
    if (!demoUserId) return;
    let cancelled = false;
    (async () => {
      const h = apiHeaders(demoUserId);
      const res = await fetch('/api/trades', { headers: h });
      if (!cancelled) setTrades(await res.json());
    })();
    return () => { cancelled = true; };
  }, [demoUserId]);

  const filtered = trades
    .filter(t => filterStatus === 'all' || t.status === filterStatus)
    .filter(t => !search || t.asset.toLowerCase().includes(search.toLowerCase()))
    .sort((a, b) => {
      const aVal = (a as Record<string, unknown>)[sortField];
      const bVal = (b as Record<string, unknown>)[sortField];
      if (aVal == null) return 1;
      if (bVal == null) return -1;
      return sortAsc ? (aVal as number) > (bVal as number) ? 1 : -1 : (aVal as number) < (bVal as number) ? 1 : -1;
    });

  async function handleSave() {
    const data = editing || emptyTrade;
    const h = apiHeaders(demoUserId);
    if (editing?.id) {
      await fetch(`/api/trades/${editing.id}`, { method: 'PUT', headers: h, body: JSON.stringify(data) });
      toast.success('Trade mis à jour');
    } else {
      await fetch('/api/trades', { method: 'POST', headers: h, body: JSON.stringify(data) });
      toast.success('Trade créé');
    }
    setShowForm(false);
    setEditing(null);
    reload();
  }

  async function handleDelete(id: string) {
    await fetch(`/api/trades/${id}`, { method: 'DELETE', headers: apiHeaders(demoUserId) });
    toast.success('Trade supprimé');
    reload();
  }

  function openEdit(trade?: Trade) {
    setEditing(trade ? { ...trade } : { ...emptyTrade });
    setShowForm(true);
  }

  async function exportCSV() {
    window.open(`/api/export?type=trades&x-user-id=${demoUserId}`, '_blank');
  }

  const formData = editing || emptyTrade;

  // Auto-calc net result
  const calcNet = () => {
    const ep = formData.exitPrice;
    const entry = formData.entryPrice;
    const lot = formData.lotSize || 0;
    const dir = formData.direction;
    if (!ep || !entry || !lot) return null;
    const pnl = dir === 'ACHAT' ? (ep - entry) * lot * 100000 : (entry - ep) * lot * 100000;
    return pnl - (formData.fees || 0);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl font-bold">Journal des trades</h2>
          <p className="text-muted-foreground text-sm mt-1">Historique complet de vos transactions</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={exportCSV}><Download className="w-4 h-4 mr-2" />Exporter CSV</Button>
          <Button onClick={() => openEdit()} className="bg-emerald-600 hover:bg-emerald-700"><Plus className="w-4 h-4 mr-2" />Nouveau trade</Button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <Input placeholder="Rechercher un actif..." value={search} onChange={e => setSearch(e.target.value)} className="max-w-xs" />
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-48"><SelectValue placeholder="Statut" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tous</SelectItem>
            {STATUSES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-left">
                <th className="p-3 text-xs text-muted-foreground font-medium cursor-pointer" onClick={() => { setSortField('asset'); setSortAsc(!sortAsc); }}>Actif <ArrowUpDown className="inline w-3 h-3" /></th>
                <th className="p-3 text-xs text-muted-foreground font-medium">Direction</th>
                <th className="p-3 text-xs text-muted-foreground font-medium hidden md:table-cell cursor-pointer" onClick={() => { setSortField('entryDate'); setSortAsc(!sortAsc); }}>Entrée <ArrowUpDown className="inline w-3 h-3" /></th>
                <th className="p-3 text-xs text-muted-foreground font-medium hidden lg:table-cell">Prix entrée</th>
                <th className="p-3 text-xs text-muted-foreground font-medium hidden lg:table-cell">SL</th>
                <th className="p-3 text-xs text-muted-foreground font-medium cursor-pointer" onClick={() => { setSortField('netResult'); setSortAsc(!sortAsc); }}>Résultat <ArrowUpDown className="inline w-3 h-3" /></th>
                <th className="p-3 text-xs text-muted-foreground font-medium hidden md:table-cell">R</th>
                <th className="p-3 text-xs text-muted-foreground font-medium">Statut</th>
                <th className="p-3 text-xs text-muted-foreground font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(trade => (
                <tr key={trade.id} className="border-b border-border/50 hover:bg-accent/50 transition-colors">
                  <td className="p-3 font-medium">{trade.asset}</td>
                  <td className="p-3"><Badge variant={trade.direction === 'ACHAT' ? 'default' : 'outline'} className={trade.direction === 'ACHAT' ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-red-600 hover:bg-red-700 text-white'}>{trade.direction}</Badge></td>
                  <td className="p-3 text-xs text-muted-foreground hidden md:table-cell">{trade.entryDate ? new Date(trade.entryDate).toLocaleDateString('fr-FR') : '-'}</td>
                  <td className="p-3 hidden lg:table-cell">{trade.entryPrice}</td>
                  <td className="p-3 hidden lg:table-cell text-red-500">{trade.initialStopLoss}</td>
                  <td className={`p-3 font-medium ${(trade.netResult || 0) >= 0 ? 'text-emerald-500' : 'text-red-500'}`}>
                    {trade.netResult ? `${(trade.netResult as number) >= 0 ? '+' : ''}$${(trade.netResult as number).toFixed(2)}` : '-'}
                  </td>
                  <td className="p-3 hidden md:table-cell font-mono">{trade.resultR ? `${(trade.resultR as number) > 0 ? '+' : ''}${trade.resultR.toFixed(2)}R` : '-'}</td>
                  <td className="p-3"><Badge className={`${STATUS_COLORS[trade.status] || 'bg-gray-500'} text-white`}>{trade.status}</Badge></td>
                  <td className="p-3">
                    <div className="flex gap-1">
                      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setViewing(trade)}><Eye className="w-3.5 h-3.5" /></Button>
                      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openEdit(trade)}><Edit className="w-3.5 h-3.5" /></Button>
                      <Button variant="ghost" size="icon" className="h-7 w-7 text-red-500" onClick={() => handleDelete(trade.id)}><Trash2 className="w-3.5 h-3.5" /></Button>
                    </div>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr><td colSpan={9} className="p-8 text-center text-muted-foreground">Aucun trade trouvé</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>

      {/* FORM DIALOG */}
      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editing?.id ? 'Modifier le trade' : 'Nouveau trade'}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div><Label>Actif</Label><Select value={formData.asset} onValueChange={v => setEditing({ ...formData, asset: v })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{ASSETS.map(a => <SelectItem key={a} value={a}>{a}</SelectItem>)}</SelectContent></Select></div>
            <div><Label>Direction</Label><Select value={formData.direction} onValueChange={v => setEditing({ ...formData, direction: v })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="ACHAT">ACHAT</SelectItem><SelectItem value="VENTE">VENTE</SelectItem></SelectContent></Select></div>
            <div><Label>Date d'entrée</Label><Input type="datetime-local" value={formData.entryDate ? new Date(formData.entryDate).toISOString().slice(0, 16) : ''} onChange={e => setEditing({ ...formData, entryDate: e.target.value ? new Date(e.target.value).toISOString() : null })} /></div>
            <div><Label>Date de sortie</Label><Input type="datetime-local" value={formData.exitDate ? new Date(formData.exitDate).toISOString().slice(0, 16) : ''} onChange={e => setEditing({ ...formData, exitDate: e.target.value ? new Date(e.target.value).toISOString() : null })} /></div>
            <div><Label>Prix d'entrée</Label><Input type="number" step="any" value={formData.entryPrice || ''} onChange={e => setEditing({ ...formData, entryPrice: parseFloat(e.target.value) || null })} /></div>
            <div><Label>Stop-loss initial</Label><Input type="number" step="any" value={formData.initialStopLoss || ''} onChange={e => setEditing({ ...formData, initialStopLoss: parseFloat(e.target.value) || null })} /></div>
            <div><Label>Take Profit 1</Label><Input type="number" step="any" value={formData.takeProfit1 || ''} onChange={e => setEditing({ ...formData, takeProfit1: parseFloat(e.target.value) || null })} /></div>
            <div><Label>Take Profit 2</Label><Input type="number" step="any" value={formData.takeProfit2 || ''} onChange={e => setEditing({ ...formData, takeProfit2: parseFloat(e.target.value) || null })} /></div>
            <div><Label>Prix de sortie</Label><Input type="number" step="any" value={formData.exitPrice || ''} onChange={e => setEditing({ ...formData, exitPrice: parseFloat(e.target.value) || null })} /></div>
            <div><Label>Taille du lot</Label><Input type="number" step="0.01" value={formData.lotSize || ''} onChange={e => setEditing({ ...formData, lotSize: parseFloat(e.target.value) || null })} /></div>
            <div><Label>Capital avant le trade</Label><Input type="number" step="any" value={formData.capitalBefore || ''} onChange={e => setEditing({ ...formData, capitalBefore: parseFloat(e.target.value) || null })} /></div>
            <div><Label>Risque (%)</Label><Input type="number" step="0.1" value={formData.riskPercent || ''} onChange={e => setEditing({ ...formData, riskPercent: parseFloat(e.target.value) || null })} /></div>
            <div><Label>Statut</Label><Select value={formData.status} onValueChange={v => setEditing({ ...formData, status: v })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{STATUSES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent></Select></div>
            <div><Label>Plan respecté</Label><Select value={formData.planRespected === null ? 'null' : formData.planRespected ? 'true' : 'false'} onValueChange={v => setEditing({ ...formData, planRespected: v === 'null' ? null : v === 'true' })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="null">Non défini</SelectItem><SelectItem value="true">Oui</SelectItem><SelectItem value="false">Non</SelectItem></SelectContent></Select></div>
            <div><Label>Émotion avant</Label><Select value={formData.emotionBefore || ''} onValueChange={v => setEditing({ ...formData, emotionBefore: v })}><SelectTrigger><SelectValue placeholder="Sélectionner" /></SelectTrigger><SelectContent>{EMOTIONS.map(e => <SelectItem key={e} value={e}>{e}</SelectItem>)}</SelectContent></Select></div>
            <div><Label>Émotion après</Label><Select value={formData.emotionAfter || ''} onValueChange={v => setEditing({ ...formData, emotionAfter: v })}><SelectTrigger><SelectValue placeholder="Sélectionner" /></SelectTrigger><SelectContent>{EMOTIONS.map(e => <SelectItem key={e} value={e}>{e}</SelectItem>)}</SelectContent></Select></div>
            <div className="md:col-span-2"><Label>Erreur principale</Label><Select value={formData.mainError || ''} onValueChange={v => setEditing({ ...formData, mainError: v })}><SelectTrigger><SelectValue placeholder="Aucune" /></SelectTrigger><SelectContent><SelectItem value="">Aucune</SelectItem>{ERRORS.map(e => <SelectItem key={e} value={e}>{e}</SelectItem>)}</SelectContent></Select></div>
            <div className="md:col-span-2"><Label>Leçon apprise</Label><Textarea value={formData.lessonLearned || ''} onChange={e => setEditing({ ...formData, lessonLearned: e.target.value })} rows={2} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => { setShowForm(false); setEditing(null); }}>Annuler</Button>
            <Button onClick={handleSave} className="bg-emerald-600 hover:bg-emerald-700">Enregistrer</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* VIEW DIALOG */}
      <Dialog open={!!viewing} onOpenChange={() => setViewing(null)}>
        <DialogContent className="max-w-lg">
          {viewing && (
            <>
              <DialogHeader><DialogTitle>{viewing.asset} - {viewing.direction}</DialogTitle></DialogHeader>
              <div className="space-y-3 text-sm">
                <div className="grid grid-cols-2 gap-2">
                  <div className="p-2 rounded bg-accent/50"><span className="text-muted-foreground text-xs">Statut</span><p><Badge className={`${STATUS_COLORS[viewing.status]} text-white`}>{viewing.status}</Badge></p></div>
                  <div className="p-2 rounded bg-accent/50"><span className="text-muted-foreground text-xs">Résultat</span><p className={`font-bold text-lg ${(viewing.netResult || 0) >= 0 ? 'text-emerald-500' : 'text-red-500'}`}>{viewing.netResult ? `$${(viewing.netResult as number) >= 0 ? '+' : ''}${viewing.netResult.toFixed(2)}` : '-'}</p></div>
                  <div className="p-2 rounded bg-accent/50"><span className="text-muted-foreground text-xs">Entrée</span><p className="font-medium">{viewing.entryPrice} ({viewing.entryDate ? new Date(viewing.entryDate).toLocaleDateString('fr-FR') : '-'})</p></div>
                  <div className="p-2 rounded bg-accent/50"><span className="text-muted-foreground text-xs">Sortie</span><p className="font-medium">{viewing.exitPrice || '-'} ({viewing.exitDate ? new Date(viewing.exitDate).toLocaleDateString('fr-FR') : '-'})</p></div>
                  <div className="p-2 rounded bg-accent/50"><span className="text-muted-foreground text-xs">SL</span><p className="text-red-500">{viewing.initialStopLoss}</p></div>
                  <div className="p-2 rounded bg-accent/50"><span className="text-muted-foreground text-xs">Résultat en R</span><p className="font-mono font-bold">{viewing.resultR ? `${viewing.resultR > 0 ? '+' : ''}${viewing.resultR.toFixed(2)}R` : '-'}</p></div>
                  <div className="p-2 rounded bg-accent/50"><span className="text-muted-foreground text-xs">Émotion avant</span><p>{viewing.emotionBefore || '-'}</p></div>
                  <div className="p-2 rounded bg-accent/50"><span className="text-muted-foreground text-xs">Plan respecté</span><p>{viewing.planRespected === null ? '-' : viewing.planRespected ? 'Oui' : 'Non'}</p></div>
                </div>
                {viewing.mainError && <div className="p-2 rounded bg-red-500/10"><span className="text-muted-foreground text-xs">Erreur</span><p className="text-red-500">{viewing.mainError}</p></div>}
                {viewing.lessonLearned && <div className="p-2 rounded bg-accent/50"><span className="text-muted-foreground text-xs">Leçon</span><p>{viewing.lessonLearned}</p></div>}
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}