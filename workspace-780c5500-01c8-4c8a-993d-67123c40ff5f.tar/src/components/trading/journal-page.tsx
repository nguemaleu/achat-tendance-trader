'use client';

import { useEffect, useState } from 'react';
import { useAppStore, apiHeaders } from '@/store/app-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Calendar } from 'lucide-react';
import { toast } from 'sonner';

const EMOTIONS = ['Calme', 'Concentré', 'Impatient', 'Stressé', 'Fatigué', 'Frustré', 'Trop confiant', 'En recherche de revanche'];
const CONCENTRATIONS = ['Faible', 'Moyen', 'Élevé', 'Très élevé'];
const ERRORS = ['Aucune', 'Entrée trop tôt', 'Achat contre la tendance', 'Absence de confirmation', 'Stop trop serré', 'Stop déplacé', 'Position trop grande', 'Surtrading', 'Entrée pendant une annonce', 'Trade de revanche', 'Objectif irréaliste', 'Non-respect du ratio rendement/risque'];

interface JournalEntry {
  id: string; date: string; startBalance: number; endBalance: number;
  dailyResult: number; tradeCount: number; winCount: number; lossCount: number;
  planRespected: boolean | null; emotionalState: string; concentrationLevel: string;
  mainError: string; bestPoint: string; correction: string;
  stoppedAfterTwoLosses: boolean; generalComment: string;
}

export function JournalPage() {
  const { demoUserId } = useAppStore();
  const [journals, setJournals] = useState<JournalEntry[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Partial<JournalEntry>>({
    date: new Date().toISOString().split('T')[0], startBalance: 0, endBalance: 0,
    dailyResult: 0, tradeCount: 0, winCount: 0, lossCount: 0,
    planRespected: null, emotionalState: 'Calme', concentrationLevel: 'Moyen',
    mainError: 'Aucune', bestPoint: '', correction: '', stoppedAfterTwoLosses: false, generalComment: '',
  });

  async function reload() {
    if (!demoUserId) return;
    const res = await fetch('/api/journals', { headers: apiHeaders(demoUserId) });
    setJournals(await res.json());
  }

  useEffect(() => {
    if (!demoUserId) return;
    let cancelled = false;
    (async () => {
      const res = await fetch('/api/journals', { headers: apiHeaders(demoUserId) });
      if (!cancelled) setJournals(await res.json());
    })();
    return () => { cancelled = true; };
  }, [demoUserId]);

  async function handleSave() {
    const h = apiHeaders(demoUserId);
    if (editing.id) {
      await fetch(`/api/journals/${editing.id}`, { method: 'PUT', headers: h, body: JSON.stringify(editing) });
      toast.success('Journal mis à jour');
    } else {
      await fetch('/api/journals', { method: 'POST', headers: h, body: JSON.stringify(editing) });
      toast.success('Journal enregistré');
    }
    setShowForm(false);
    setEditing({
      date: new Date().toISOString().split('T')[0], startBalance: 0, endBalance: 0,
      dailyResult: 0, tradeCount: 0, winCount: 0, lossCount: 0,
      planRespected: null, emotionalState: 'Calme', concentrationLevel: 'Moyen',
      mainError: 'Aucune', bestPoint: '', correction: '', stoppedAfterTwoLosses: false, generalComment: '',
    });
    reload();
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl font-bold">Journal quotidien</h2>
          <p className="text-muted-foreground text-sm mt-1">Enregistrez et révisez votre journée de trading</p>
        </div>
        <Button onClick={() => setShowForm(true)} className="bg-emerald-600 hover:bg-emerald-700">
          <Plus className="w-4 h-4 mr-2" />Nouvelle entrée
        </Button>
      </div>

      {/* Journal entries list */}
      <div className="space-y-3">
        {journals.map(j => (
          <Card key={j.id} className="hover:border-emerald-500/20 transition-colors">
            <CardContent className="p-4">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="text-center min-w-[50px] p-2 rounded-lg bg-accent/50">
                    <Calendar className="w-4 h-4 mx-auto text-muted-foreground mb-1" />
                    <p className="text-xs font-medium">{new Date(j.date).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' })}</p>
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className={`text-lg font-bold ${j.dailyResult >= 0 ? 'text-emerald-500' : 'text-red-500'}`}>${j.dailyResult >= 0 ? '+' : ''}{j.dailyResult.toFixed(2)}</p>
                      <span className="text-xs text-muted-foreground">({j.tradeCount} trades)</span>
                    </div>
                    <p className="text-xs text-muted-foreground">{j.winCount} gains / {j.lossCount} pertes</p>
                  </div>
                </div>
                <div className="flex flex-wrap gap-2 text-xs">
                  {j.emotionalState && <span className="px-2 py-1 rounded-full bg-accent">{j.emotionalState}</span>}
                  {j.planRespected === true && <span className="px-2 py-1 rounded-full bg-emerald-500/10 text-emerald-500">Plan respecté</span>}
                  {j.planRespected === false && <span className="px-2 py-1 rounded-full bg-red-500/10 text-red-500">Plan NON respecté</span>}
                  {j.stoppedAfterTwoLosses && <span className="px-2 py-1 rounded-full bg-amber-500/10 text-amber-500">Arrêt 2 pertes</span>}
                </div>
              </div>
              {j.mainError && j.mainError !== 'Aucune' && (
                <div className="mt-2 text-xs text-red-500">Erreur: {j.mainError}</div>
              )}
              {j.generalComment && (
                <div className="mt-2 text-xs text-muted-foreground">{j.generalComment}</div>
              )}
            </CardContent>
          </Card>
        ))}
        {journals.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            <Calendar className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p>Aucune entrée de journal</p>
            <p className="text-sm mt-1">Commencez à enregistrer votre journée de trading</p>
          </div>
        )}
      </div>

      {/* FORM DIALOG */}
      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Nouvelle entrée de journal</DialogTitle></DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div><Label>Date</Label><Input type="date" value={editing.date} onChange={e => setEditing({ ...editing, date: e.target.value })} /></div>
            <div><Label>Nombre de trades</Label><Input type="number" value={editing.tradeCount || ''} onChange={e => setEditing({ ...editing, tradeCount: parseInt(e.target.value) || 0 })} /></div>
            <div><Label>Solde de départ ($)</Label><Input type="number" step="any" value={editing.startBalance || ''} onChange={e => { const v = parseFloat(e.target.value) || 0; setEditing({ ...editing, startBalance: v, dailyResult: v - (editing.endBalance || 0) }); }} /></div>
            <div><Label>Solde de fin ($)</Label><Input type="number" step="any" value={editing.endBalance || ''} onChange={e => { const v = parseFloat(e.target.value) || 0; setEditing({ ...editing, endBalance: v, dailyResult: v - (editing.startBalance || 0) }); }} /></div>
            <div><Label>Résultat ($)</Label><Input disabled value={`${editing.dailyResult >= 0 ? '+' : ''}${editing.dailyResult.toFixed(2)}`} className={editing.dailyResult >= 0 ? 'text-emerald-500' : 'text-red-500'} /></div>
            <div className="grid grid-cols-2 gap-2">
              <div><Label>Gains</Label><Input type="number" value={editing.winCount || ''} onChange={e => setEditing({ ...editing, winCount: parseInt(e.target.value) || 0 })} /></div>
              <div><Label>Pertes</Label><Input type="number" value={editing.lossCount || ''} onChange={e => setEditing({ ...editing, lossCount: parseInt(e.target.value) || 0 })} /></div>
            </div>
            <div><Label>État émotionnel</Label><Select value={editing.emotionalState || ''} onValueChange={v => setEditing({ ...editing, emotionalState: v })}><SelectTrigger><SelectValue placeholder="Sélectionner" /></SelectTrigger><SelectContent>{EMOTIONS.map(e => <SelectItem key={e} value={e}>{e}</SelectItem>)}</SelectContent></Select></div>
            <div><Label>Concentration</Label><Select value={editing.concentrationLevel || ''} onValueChange={v => setEditing({ ...editing, concentrationLevel: v })}><SelectTrigger><SelectValue placeholder="Sélectionner" /></SelectTrigger><SelectContent>{CONCENTRATIONS.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent></Select></div>
            <div><Label>Erreur principale</Label><Select value={editing.mainError || ''} onValueChange={v => setEditing({ ...editing, mainError: v })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{ERRORS.map(e => <SelectItem key={e} value={e}>{e}</SelectItem>)}</SelectContent></Select></div>
            <div><Label>Plan respecté</Label><Select value={editing.planRespected === null ? 'null' : editing.planRespected ? 'true' : 'false'} onValueChange={v => setEditing({ ...editing, planRespected: v === 'null' ? null : v === 'true' })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="null">Non défini</SelectItem><SelectItem value="true">Oui</SelectItem><SelectItem value="false">Non</SelectItem></SelectContent></Select></div>
            <div className="md:col-span-2"><Label>Meilleur point de la journée</Label><Textarea value={editing.bestPoint || ''} onChange={e => setEditing({ ...editing, bestPoint: e.target.value })} rows={2} /></div>
            <div className="md:col-span-2"><Label>Correction à appliquer</Label><Textarea value={editing.correction || ''} onChange={e => setEditing({ ...editing, correction: e.target.value })} rows={2} /></div>
            <div className="md:col-span-2 flex items-center gap-2">
              <Switch checked={editing.stoppedAfterTwoLosses || false} onCheckedChange={v => setEditing({ ...editing, stoppedAfterTwoLosses: v })} />
              <Label>Arrêt après deux pertes</Label>
            </div>
            <div className="md:col-span-2"><Label>Commentaire général</Label><Textarea value={editing.generalComment || ''} onChange={e => setEditing({ ...editing, generalComment: e.target.value })} rows={3} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowForm(false)}>Annuler</Button>
            <Button onClick={handleSave} className="bg-emerald-600 hover:bg-emerald-700">Enregistrer</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}