'use client';

import { useEffect, useState, useMemo } from 'react';
import { useAppStore, apiHeaders } from '@/store/app-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Eye, Edit, Trash2, Search, LayoutGrid, List, Calendar, TrendingUp, TrendingDown, Minus, ChevronLeft, ChevronRight } from 'lucide-react';
import { toast } from 'sonner';

const ASSETS = ['XAU/USD', 'EUR/USD', 'GBP/USD', 'NASDAQ', 'USD/JPY', 'USD/CAD', 'AUD/USD', 'S&P 500', 'DAX'];
const CATEGORIES = ['Devise', 'Indice', 'Matiere', 'Crypto'];
const SESSIONS = ['Londres', 'New York', 'Asie', 'Overlap Londres/NY'];
const TIMEFRAMES = ['M5', 'M15', 'M30', 'H1', 'H4', 'D1'];
const TRENDS = ['Haussier', 'Baissier', 'Neutre'];
const STATUSES = ['A analyser', 'En cours', 'Validee', 'Entree', 'Annulee'];

const STATUS_COLORS: Record<string, string> = {
  'A analyser': 'bg-slate-500',
  'En cours': 'bg-amber-500',
  'Validee': 'bg-emerald-500',
  'Entree': 'bg-blue-500',
  'Annulee': 'bg-gray-600',
};

const TREND_ICONS: Record<string, React.ElementType> = {
  'Haussier': TrendingUp,
  'Baissier': TrendingDown,
  'Neutre': Minus,
};

const TREND_COLORS: Record<string, string> = {
  'Haussier': 'text-emerald-500',
  'Baissier': 'text-red-500',
  'Neutre': 'text-amber-500',
};

interface Opportunity {
  id: string;
  name: string;
  analysisDate: string;
  asset: string;
  marketCategory: string;
  tradingSession: string;
  primaryTimeframe: string;
  entryTimeframe: string;
  trendH4: string;
  trendH1: string;
  currentPrice: number | null;
  mainSupport: number | null;
  mainResistance: number | null;
  plannedEntry: number | null;
  plannedStopLoss: number | null;
  takeProfit1: number | null;
  takeProfit2: number | null;
  riskRewardRatio: number | null;
  validationScore: number;
  checklistJson: string;
  status: string;
  comments: string;
  createdAt: string;
  updatedAt: string;
}

const emptyOpportunity: Partial<Opportunity> = {
  asset: 'XAU/USD',
  marketCategory: 'Devise',
  tradingSession: 'Londres',
  primaryTimeframe: 'H4',
  entryTimeframe: 'M15',
  trendH4: '',
  trendH1: '',
  validationScore: 0,
  status: 'A analyser',
  comments: '',
};

type ViewMode = 'table' | 'card' | 'calendar';

export function OpportunitiesPage() {
  const { demoUserId } = useAppStore();
  const [opportunities, setOpportunities] = useState<Opportunity[]>([]);
  const [viewMode, setViewMode] = useState<ViewMode>('card');
  const [filterStatus, setFilterStatus] = useState('all');
  const [search, setSearch] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Partial<Opportunity> | null>(null);
  const [viewing, setViewing] = useState<Opportunity | null>(null);
  const [calendarDate, setCalendarDate] = useState(new Date());

  async function reload() {
    if (!demoUserId) return;
    const h = apiHeaders(demoUserId);
    const res = await fetch('/api/opportunities', { headers: h });
    setOpportunities(await res.json());
  }

  useEffect(() => {
    if (!demoUserId) return;
    let cancelled = false;
    (async () => {
      const h = apiHeaders(demoUserId);
      const res = await fetch('/api/opportunities', { headers: h });
      if (!cancelled) setOpportunities(await res.json());
    })();
    return () => { cancelled = true; };
  }, [demoUserId]);

  const filtered = useMemo(() => {
    return opportunities
      .filter(o => filterStatus === 'all' || o.status === filterStatus)
      .filter(o => !search ||
        o.asset.toLowerCase().includes(search.toLowerCase()) ||
        o.name.toLowerCase().includes(search.toLowerCase()) ||
        o.marketCategory.toLowerCase().includes(search.toLowerCase())
      );
  }, [opportunities, filterStatus, search]);

  async function handleSave() {
    const data = editing || emptyOpportunity;
    const h = apiHeaders(demoUserId);
    if (editing?.id) {
      await fetch(`/api/opportunities/${editing.id}`, { method: 'PUT', headers: h, body: JSON.stringify(data) });
      toast.success('Opportunite mise a jour');
    } else {
      await fetch('/api/opportunities', { method: 'POST', headers: h, body: JSON.stringify(data) });
      toast.success('Opportunite creee');
    }
    setShowForm(false);
    setEditing(null);
    reload();
  }

  async function handleDelete(id: string) {
    await fetch(`/api/opportunities/${id}`, { method: 'DELETE', headers: apiHeaders(demoUserId) });
    toast.success('Opportunite supprimee');
    reload();
  }

  function openEdit(opp?: Opportunity) {
    setEditing(opp ? { ...opp } : { ...emptyOpportunity });
    setShowForm(true);
  }

  const formData = editing || emptyOpportunity;

  function updateForm(field: string, value: unknown) {
    setEditing({ ...formData, [field]: value });
  }

  // Calendar helpers
  const calendarYear = calendarDate.getFullYear();
  const calendarMonth = calendarDate.getMonth();
  const firstDay = new Date(calendarYear, calendarMonth, 1).getDay();
  const daysInMonth = new Date(calendarYear, calendarMonth + 1, 0).getDate();
  const calendarDays = Array.from({ length: daysInMonth }, (_, i) => i + 1);
  const adjustedFirstDay = firstDay === 0 ? 6 : firstDay - 1;

  function getOpportunitiesForDay(day: number) {
    return filtered.filter(o => {
      const d = new Date(o.analysisDate || o.createdAt);
      return d.getFullYear() === calendarYear && d.getMonth() === calendarMonth && d.getDate() === day;
    });
  }

  function prevMonth() {
    setCalendarDate(new Date(calendarYear, calendarMonth - 1, 1));
  }

  function nextMonth() {
    setCalendarDate(new Date(calendarYear, calendarMonth + 1, 1));
  }

  const monthNames = ['Janvier', 'Fevrier', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Aout', 'Septembre', 'Octobre', 'Novembre', 'Decembre'];

  function scoreColor(score: number) {
    if (score >= 10) return 'text-emerald-500';
    if (score >= 7) return 'text-amber-500';
    return 'text-red-500';
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl font-bold">Opportunites</h2>
          <p className="text-muted-foreground text-sm mt-1">Gerez et suivez vos opportunites de trading</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => openEdit()} className="bg-emerald-600 hover:bg-emerald-700">
            <Plus className="w-4 h-4 mr-2" />Nouvelle opportunite
          </Button>
        </div>
      </div>

      {/* Filters and view toggle */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1 max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Rechercher..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
        </div>
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-48"><SelectValue placeholder="Statut" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tous</SelectItem>
            {STATUSES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
          </SelectContent>
        </Select>
        <div className="flex gap-1 bg-accent/50 rounded-lg p-1">
          <Button variant={viewMode === 'card' ? 'default' : 'ghost'} size="sm" onClick={() => setViewMode('card')}>
            <LayoutGrid className="w-4 h-4" />
          </Button>
          <Button variant={viewMode === 'table' ? 'default' : 'ghost'} size="sm" onClick={() => setViewMode('table')}>
            <List className="w-4 h-4" />
          </Button>
          <Button variant={viewMode === 'calendar' ? 'default' : 'ghost'} size="sm" onClick={() => setViewMode('calendar')}>
            <Calendar className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* CARD VIEW */}
      {viewMode === 'card' && (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filtered.map(opp => (
            <Card key={opp.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-4 space-y-3">
                {/* Top row: asset badge + status + score */}
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="font-mono text-xs">{opp.asset}</Badge>
                    <Badge className={`${STATUS_COLORS[opp.status] || 'bg-gray-500'} text-white text-[10px]`}>
                      {opp.status}
                    </Badge>
                  </div>
                  <div className={`text-2xl font-bold ${scoreColor(opp.validationScore)}`}>
                    {opp.validationScore}/13
                  </div>
                </div>

                {/* Name */}
                <h3 className="font-semibold text-sm line-clamp-1">{opp.name || opp.asset}</h3>

                {/* Meta info */}
                <div className="flex flex-wrap gap-1.5 text-[10px] text-muted-foreground">
                  <span className="px-1.5 py-0.5 rounded bg-accent/50">{opp.marketCategory}</span>
                  <span className="px-1.5 py-0.5 rounded bg-accent/50">{opp.tradingSession}</span>
                  <span className="px-1.5 py-0.5 rounded bg-accent/50">{opp.primaryTimeframe}/{opp.entryTimeframe}</span>
                </div>

                {/* Trend badges */}
                <div className="flex gap-2">
                  {opp.trendH4 && (
                    <div className="flex items-center gap-1 px-2 py-1 rounded-md bg-accent/50">
                      {(() => {
                        const Icon = TREND_ICONS[opp.trendH4] || Minus;
                        return <Icon className={`w-3.5 h-3.5 ${TREND_COLORS[opp.trendH4] || ''}`} />;
                      })()}
                      <span className={`text-xs font-medium ${TREND_COLORS[opp.trendH4] || ''}`}>H4 {opp.trendH4}</span>
                    </div>
                  )}
                  {opp.trendH1 && (
                    <div className="flex items-center gap-1 px-2 py-1 rounded-md bg-accent/50">
                      {(() => {
                        const Icon = TREND_ICONS[opp.trendH1] || Minus;
                        return <Icon className={`w-3.5 h-3.5 ${TREND_COLORS[opp.trendH1] || ''}`} />;
                      })()}
                      <span className={`text-xs font-medium ${TREND_COLORS[opp.trendH1] || ''}`}>H1 {opp.trendH1}</span>
                    </div>
                  )}
                </div>

                {/* Price info */}
                {opp.currentPrice && (
                  <div className="grid grid-cols-3 gap-2 text-xs">
                    <div>
                      <span className="text-muted-foreground">Prix</span>
                      <p className="font-medium">{opp.currentPrice}</p>
                    </div>
                    {opp.mainSupport && (
                      <div>
                        <span className="text-muted-foreground">Support</span>
                        <p className="font-medium text-emerald-500">{opp.mainSupport}</p>
                      </div>
                    )}
                    {opp.mainResistance && (
                      <div>
                        <span className="text-muted-foreground">Resistance</span>
                        <p className="font-medium text-red-500">{opp.mainResistance}</p>
                      </div>
                    )}
                  </div>
                )}

                {/* R/R ratio */}
                {opp.riskRewardRatio && opp.riskRewardRatio > 0 && (
                  <Badge variant={opp.riskRewardRatio >= 2 ? 'default' : 'destructive'} className={opp.riskRewardRatio >= 2 ? 'bg-emerald-600' : ''}>
                    R/R {opp.riskRewardRatio.toFixed(1)}:1
                  </Badge>
                )}

                {/* Actions */}
                <div className="flex gap-1 pt-2 border-t border-border">
                  <Button variant="ghost" size="sm" className="flex-1 h-8" onClick={() => setViewing(opp)}>
                    <Eye className="w-3.5 h-3.5 mr-1" />Voir
                  </Button>
                  <Button variant="ghost" size="sm" className="flex-1 h-8" onClick={() => openEdit(opp)}>
                    <Edit className="w-3.5 h-3.5 mr-1" />Modifier
                  </Button>
                  <Button variant="ghost" size="sm" className="h-8 text-red-500" onClick={() => handleDelete(opp.id)}>
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
          {filtered.length === 0 && (
            <div className="col-span-full py-12 text-center text-muted-foreground">
              Aucune opportunite trouvee
            </div>
          )}
        </div>
      )}

      {/* TABLE VIEW */}
      {viewMode === 'table' && (
        <Card>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border text-left">
                  <th className="p-3 text-xs text-muted-foreground font-medium">Actif</th>
                  <th className="p-3 text-xs text-muted-foreground font-medium">Nom</th>
                  <th className="p-3 text-xs text-muted-foreground font-medium hidden md:table-cell">Tendance H4</th>
                  <th className="p-3 text-xs text-muted-foreground font-medium hidden md:table-cell">Tendance H1</th>
                  <th className="p-3 text-xs text-muted-foreground font-medium">Score</th>
                  <th className="p-3 text-xs text-muted-foreground font-medium hidden lg:table-cell">R/R</th>
                  <th className="p-3 text-xs text-muted-foreground font-medium">Statut</th>
                  <th className="p-3 text-xs text-muted-foreground font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(opp => (
                  <tr key={opp.id} className="border-b border-border/50 hover:bg-accent/50 transition-colors">
                    <td className="p-3 font-medium font-mono">{opp.asset}</td>
                    <td className="p-3 truncate max-w-[150px]">{opp.name || '-'}</td>
                    <td className="p-3 hidden md:table-cell">
                      {opp.trendH4 ? (
                        <span className={`flex items-center gap-1 ${TREND_COLORS[opp.trendH4] || ''}`}>
                          {(() => { const I = TREND_ICONS[opp.trendH4] || Minus; return <I className="w-3.5 h-3.5" />; })()}
                          {opp.trendH4}
                        </span>
                      ) : '-'}
                    </td>
                    <td className="p-3 hidden md:table-cell">
                      {opp.trendH1 ? (
                        <span className={`flex items-center gap-1 ${TREND_COLORS[opp.trendH1] || ''}`}>
                          {(() => { const I = TREND_ICONS[opp.trendH1] || Minus; return <I className="w-3.5 h-3.5" />; })()}
                          {opp.trendH1}
                        </span>
                      ) : '-'}
                    </td>
                    <td className={`p-3 font-bold ${scoreColor(opp.validationScore)}`}>{opp.validationScore}/13</td>
                    <td className="p-3 hidden lg:table-cell">{opp.riskRewardRatio ? `${opp.riskRewardRatio.toFixed(1)}:1` : '-'}</td>
                    <td className="p-3"><Badge className={`${STATUS_COLORS[opp.status] || 'bg-gray-500'} text-white`}>{opp.status}</Badge></td>
                    <td className="p-3">
                      <div className="flex gap-1">
                        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setViewing(opp)}><Eye className="w-3.5 h-3.5" /></Button>
                        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openEdit(opp)}><Edit className="w-3.5 h-3.5" /></Button>
                        <Button variant="ghost" size="icon" className="h-7 w-7 text-red-500" onClick={() => handleDelete(opp.id)}><Trash2 className="w-3.5 h-3.5" /></Button>
                      </div>
                    </td>
                  </tr>
                ))}
                {filtered.length === 0 && (
                  <tr><td colSpan={8} className="p-8 text-center text-muted-foreground">Aucune opportunite trouvee</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {/* CALENDAR VIEW */}
      {viewMode === 'calendar' && (
        <Card>
          <CardContent className="p-4">
            {/* Calendar header */}
            <div className="flex items-center justify-between mb-4">
              <Button variant="ghost" size="icon" onClick={prevMonth}><ChevronLeft className="w-4 h-4" /></Button>
              <h3 className="text-lg font-semibold">{monthNames[calendarMonth]} {calendarYear}</h3>
              <Button variant="ghost" size="icon" onClick={nextMonth}><ChevronRight className="w-4 h-4" /></Button>
            </div>

            {/* Day headers */}
            <div className="grid grid-cols-7 gap-1 mb-1">
              {['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'].map(d => (
                <div key={d} className="text-center text-xs text-muted-foreground font-medium py-1">{d}</div>
              ))}
            </div>

            {/* Calendar grid */}
            <div className="grid grid-cols-7 gap-1">
              {/* Empty cells before first day */}
              {Array.from({ length: adjustedFirstDay }, (_, i) => (
                <div key={`empty-${i}`} className="min-h-[80px] rounded-lg bg-accent/20" />
              ))}

              {/* Day cells */}
              {calendarDays.map(day => {
                const dayOpps = getOpportunitiesForDay(day);
                return (
                  <div key={day} className="min-h-[80px] rounded-lg border border-border/50 p-1 hover:bg-accent/30 transition-colors">
                    <span className="text-xs text-muted-foreground font-medium">{day}</span>
                    <div className="space-y-0.5 mt-0.5">
                      {dayOpps.slice(0, 2).map(o => (
                        <div
                          key={o.id}
                          className="text-[10px] px-1 py-0.5 rounded cursor-pointer truncate text-white"
                          style={{ backgroundColor: STATUS_COLORS[o.status]?.replace('bg-', '') === 'slate-500' ? '#64748b' : STATUS_COLORS[o.status] === 'bg-amber-500' ? '#f59e0b' : STATUS_COLORS[o.status] === 'bg-emerald-500' ? '#10b981' : STATUS_COLORS[o.status] === 'bg-blue-500' ? '#3b82f6' : '#4b5563' }}
                          onClick={() => setViewing(o)}
                        >
                          {o.asset}
                        </div>
                      ))}
                      {dayOpps.length > 2 && (
                        <span className="text-[10px] text-muted-foreground">+{dayOpps.length - 2}</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* FORM DIALOG */}
      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing?.id ? "Modifier l&apos;opportunite" : 'Nouvelle opportunite'}</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Basic info */}
            <div>
              <Label>Nom</Label>
              <Input value={formData.name || ''} onChange={e => updateForm('name', e.target.value)} placeholder="Description de l&apos;opportunite" />
            </div>
            <div>
              <Label>Actif</Label>
              <Select value={formData.asset} onValueChange={v => updateForm('asset', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{ASSETS.map(a => <SelectItem key={a} value={a}>{a}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label>Categorie</Label>
              <Select value={formData.marketCategory} onValueChange={v => updateForm('marketCategory', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{CATEGORIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label>Session</Label>
              <Select value={formData.tradingSession} onValueChange={v => updateForm('tradingSession', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{SESSIONS.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
              </Select>
            </div>

            {/* Timeframes */}
            <div>
              <Label>Unite de temps principale</Label>
              <Select value={formData.primaryTimeframe} onValueChange={v => updateForm('primaryTimeframe', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{TIMEFRAMES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label>Unite de temps d&apos;entree</Label>
              <Select value={formData.entryTimeframe} onValueChange={v => updateForm('entryTimeframe', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{TIMEFRAMES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
              </Select>
            </div>

            {/* Trends */}
            <div>
              <Label>Tendance H4</Label>
              <Select value={formData.trendH4 || ''} onValueChange={v => updateForm('trendH4', v)}>
                <SelectTrigger><SelectValue placeholder="Selectionner" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Non defini</SelectItem>
                  {TRENDS.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Tendance H1</Label>
              <Select value={formData.trendH1 || ''} onValueChange={v => updateForm('trendH1', v)}>
                <SelectTrigger><SelectValue placeholder="Selectionner" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Non defini</SelectItem>
                  {TRENDS.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            {/* Prices */}
            <div>
              <Label>Prix actuel</Label>
              <Input type="number" step="any" value={formData.currentPrice || ''} onChange={e => updateForm('currentPrice', parseFloat(e.target.value) || null)} />
            </div>
            <div>
              <Label>Support principal</Label>
              <Input type="number" step="any" value={formData.mainSupport || ''} onChange={e => updateForm('mainSupport', parseFloat(e.target.value) || null)} />
            </div>
            <div>
              <Label>Resistance principale</Label>
              <Input type="number" step="any" value={formData.mainResistance || ''} onChange={e => updateForm('mainResistance', parseFloat(e.target.value) || null)} />
            </div>
            <div>
              <Label>Entree planifiee</Label>
              <Input type="number" step="any" value={formData.plannedEntry || ''} onChange={e => updateForm('plannedEntry', parseFloat(e.target.value) || null)} />
            </div>
            <div>
              <Label>Stop-loss</Label>
              <Input type="number" step="any" value={formData.plannedStopLoss || ''} onChange={e => updateForm('plannedStopLoss', parseFloat(e.target.value) || null)} />
            </div>
            <div>
              <Label>Take Profit 1</Label>
              <Input type="number" step="any" value={formData.takeProfit1 || ''} onChange={e => updateForm('takeProfit1', parseFloat(e.target.value) || null)} />
            </div>
            <div>
              <Label>Take Profit 2</Label>
              <Input type="number" step="any" value={formData.takeProfit2 || ''} onChange={e => updateForm('takeProfit2', parseFloat(e.target.value) || null)} />
            </div>

            {/* Score and Status */}
            <div>
              <Label>Score de validation (/13)</Label>
              <Input type="number" min="0" max="13" value={formData.validationScore || 0} onChange={e => updateForm('validationScore', parseInt(e.target.value) || 0)} />
            </div>
            <div>
              <Label>Statut</Label>
              <Select value={formData.status} onValueChange={v => updateForm('status', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{STATUSES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
              </Select>
            </div>

            {/* Comments */}
            <div className="md:col-span-2">
              <Label>Commentaires</Label>
              <Textarea value={formData.comments || ''} onChange={e => updateForm('comments', e.target.value)} rows={3} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => { setShowForm(false); setEditing(null); }}>Annuler</Button>
            <Button onClick={handleSave} className="bg-emerald-600 hover:bg-emerald-700">Enregistrer</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* VIEW DIALOG */}
      <Dialog open={!!viewing} onOpenChange={() => setViewing(null)}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          {viewing && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <span className="font-mono">{viewing.asset}</span>
                  <Badge className={`${STATUS_COLORS[viewing.status] || 'bg-gray-500'} text-white`}>{viewing.status}</Badge>
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-3 text-sm">
                <div className="grid grid-cols-2 gap-2">
                  <div className="p-2 rounded bg-accent/50">
                    <span className="text-muted-foreground text-xs">Nom</span>
                    <p className="font-medium">{viewing.name || '-'}</p>
                  </div>
                  <div className="p-2 rounded bg-accent/50">
                    <span className="text-muted-foreground text-xs">Score</span>
                    <p className={`text-xl font-bold ${scoreColor(viewing.validationScore)}`}>{viewing.validationScore}/13</p>
                  </div>
                  <div className="p-2 rounded bg-accent/50">
                    <span className="text-muted-foreground text-xs">Categorie</span>
                    <p>{viewing.marketCategory}</p>
                  </div>
                  <div className="p-2 rounded bg-accent/50">
                    <span className="text-muted-foreground text-xs">Session</span>
                    <p>{viewing.tradingSession || '-'}</p>
                  </div>
                  <div className="p-2 rounded bg-accent/50">
                    <span className="text-muted-foreground text-xs">Tendance H4</span>
                    <p className={TREND_COLORS[viewing.trendH4] || ''}>{viewing.trendH4 || '-'}</p>
                  </div>
                  <div className="p-2 rounded bg-accent/50">
                    <span className="text-muted-foreground text-xs">Tendance H1</span>
                    <p className={TREND_COLORS[viewing.trendH1] || ''}>{viewing.trendH1 || '-'}</p>
                  </div>
                </div>

                {/* Price details */}
                <div className="grid grid-cols-2 gap-2">
                  {viewing.currentPrice && (
                    <div className="p-2 rounded bg-accent/50">
                      <span className="text-muted-foreground text-xs">Prix actuel</span>
                      <p className="font-medium">{viewing.currentPrice}</p>
                    </div>
                  )}
                  {viewing.mainSupport && (
                    <div className="p-2 rounded bg-emerald-500/10">
                      <span className="text-muted-foreground text-xs">Support</span>
                      <p className="font-medium text-emerald-500">{viewing.mainSupport}</p>
                    </div>
                  )}
                  {viewing.mainResistance && (
                    <div className="p-2 rounded bg-red-500/10">
                      <span className="text-muted-foreground text-xs">Resistance</span>
                      <p className="font-medium text-red-500">{viewing.mainResistance}</p>
                    </div>
                  )}
                  {viewing.plannedEntry && (
                    <div className="p-2 rounded bg-accent/50">
                      <span className="text-muted-foreground text-xs">Entree planifiee</span>
                      <p className="font-medium">{viewing.plannedEntry}</p>
                    </div>
                  )}
                  {viewing.plannedStopLoss && (
                    <div className="p-2 rounded bg-red-500/10">
                      <span className="text-muted-foreground text-xs">Stop-loss</span>
                      <p className="font-medium text-red-500">{viewing.plannedStopLoss}</p>
                    </div>
                  )}
                  {viewing.takeProfit1 && (
                    <div className="p-2 rounded bg-emerald-500/10">
                      <span className="text-muted-foreground text-xs">TP1</span>
                      <p className="font-medium text-emerald-500">{viewing.takeProfit1}</p>
                    </div>
                  )}
                  {viewing.takeProfit2 && (
                    <div className="p-2 rounded bg-emerald-500/10">
                      <span className="text-muted-foreground text-xs">TP2</span>
                      <p className="font-medium text-emerald-500">{viewing.takeProfit2}</p>
                    </div>
                  )}
                </div>

                {viewing.riskRewardRatio && viewing.riskRewardRatio > 0 && (
                  <Badge variant={viewing.riskRewardRatio >= 2 ? 'default' : 'destructive'} className={viewing.riskRewardRatio >= 2 ? 'bg-emerald-600' : ''}>
                    Ratio R/R: {viewing.riskRewardRatio.toFixed(2)}:1
                  </Badge>
                )}

                {viewing.comments && (
                  <div className="p-2 rounded bg-accent/50">
                    <span className="text-muted-foreground text-xs">Commentaires</span>
                    <p className="mt-1">{viewing.comments}</p>
                  </div>
                )}

                <div className="text-xs text-muted-foreground">
                  Analyse: {new Date(viewing.analysisDate || viewing.createdAt).toLocaleDateString('fr-FR')}
                </div>
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={() => setViewing(null)}>Fermer</Button>
                <Button onClick={() => { setViewing(null); openEdit(viewing); }} className="bg-emerald-600 hover:bg-emerald-700">
                  <Edit className="w-4 h-4 mr-2" />Modifier
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
