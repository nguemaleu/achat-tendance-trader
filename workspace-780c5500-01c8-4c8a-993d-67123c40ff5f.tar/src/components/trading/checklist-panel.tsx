'use client';

import { Card, CardContent } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, XCircle } from 'lucide-react';

const CRITERIA_BY_TF: { group: string; tf: string; icon: string; items: { key: string; label: string; mandatory: boolean }[] }[] = [
  {
    group: 'H4 - Tendance generale',
    tf: 'H4',
    icon: '4H',
    items: [
      { key: 'c1', label: "Le prix est au-dessus de l'EMA 200 sur H4.", mandatory: true },
      { key: 'c2', label: "L'EMA 20 est au-dessus de l'EMA 50 sur H4.", mandatory: false },
      { key: 'c3', label: "Les EMA sont orientees vers le haut sur H4.", mandatory: false },
    ],
  },
  {
    group: 'H1 - Structure du marche',
    tf: 'H1',
    icon: '1H',
    items: [
      { key: 'c4', label: "Sommets et creux ascendants sur H1.", mandatory: true },
      { key: 'c5', label: "Le prix est au-dessus de l'EMA 200 sur H1.", mandatory: true },
      { key: 'c6', label: "L'EMA 20 est au-dessus de l'EMA 50 sur H1.", mandatory: false },
      { key: 'c7', label: "L'EMA 50 est orientee vers le haut sur H1.", mandatory: false },
    ],
  },
  {
    group: 'M15 - Entree',
    tf: 'M15',
    icon: '15',
    items: [
      { key: 'c8', label: "Le prix revient sur un support ou une ancienne resistance devenue support.", mandatory: true },
      { key: 'c9', label: "Une bougie haussiere de confirmation a clote sur M15.", mandatory: true },
      { key: 'c10', label: "Le RSI remonte au-dessus de 50.", mandatory: false },
      { key: 'c11', label: "Le MACD donne un signal haussier.", mandatory: false },
    ],
  },
  {
    group: 'Gestion du risque',
    tf: 'RISQUE',
    icon: 'RR',
    items: [
      { key: 'c12', label: "Le ratio rendement/risque est au minimum de 2 pour 1.", mandatory: true },
      { key: 'c13', label: "Aucune annonce economique majeure n'est imminente.", mandatory: false },
    ],
  },
];

const ALL_CRITERIA = CRITERIA_BY_TF.flatMap(g => g.items);
const TOTAL = ALL_CRITERIA.length;
const MANDATORY_KEYS = ALL_CRITERIA.filter(c => c.mandatory).map(c => c.key);

export const EXCLUSION_CRITERIA = [
  { key: 'e1', label: 'La tendance H4 est baissiere.' },
  { key: 'e2', label: 'H4 est haussier mais H1 est clairement baissier.' },
  { key: 'e3', label: 'Les EMA 20, 50 et 200 sont plates ou entremeles.' },
  { key: 'e4', label: 'Le marche evolue sans direction (range/sideways).' },
  { key: 'e5', label: 'Le prix monte fortement sans repli (tendance trop avancee).' },
  { key: 'e6', label: 'La bougie de confirmation n\'\'est pas encore clotee.' },
  { key: 'e7', label: 'Une annonce economique importante est imminente.' },
];

const MANDATORY_MISSING_LABELS: Record<string, string> = {
  c1: 'Prix au-dessus EMA 200 (H4)',
  c4: 'Structure haussiere H1',
  c5: 'Prix au-dessus EMA 200 (H1)',
  c8: 'Retour sur support (M15)',
  c9: 'Bougie de confirmation (M15)',
  c12: 'Ratio min. 2:1',
};

export const CHECKLIST_KEYS: Record<string, boolean> = {};
ALL_CRITERIA.forEach(c => { CHECKLIST_KEYS[c.key] = false; });
export const EXCLUSION_KEYS: Record<string, boolean> = {};
EXCLUSION_CRITERIA.forEach(c => { EXCLUSION_KEYS[c.key] = false; });

interface ChecklistPanelProps {
  checklist: Record<string, boolean>;
  exclusions: Record<string, boolean>;
  onChange: (key: string, value: boolean) => void;
  onExclusionChange: (key: string, value: boolean) => void;
  embedded?: boolean;
  showExclusions?: boolean;
}

export function ChecklistPanel({ checklist, exclusions, onChange, onExclusionChange, embedded, showExclusions = true }: ChecklistPanelProps) {
  const score = Object.values(checklist).filter(Boolean).length;
  const mandatoryMissing = MANDATORY_KEYS.filter(k => !checklist[k]);
  const activeExclusions = Object.entries(exclusions || {}).filter(([, v]) => v).length;

  let decision = '';
  let decisionColor = 'text-red-500';
  let decisionBg = 'border-red-500/50 bg-red-500/10';

  if (activeExclusions > 0) {
    decision = 'NE PAS ENTRER - Exclusion(s) active(s)';
    decisionColor = 'text-red-500';
    decisionBg = 'border-red-500/50 bg-red-500/10';
  } else if (score <= 6) {
    decision = 'Ne pas entrer';
    decisionColor = 'text-red-500';
    decisionBg = 'border-red-500/50 bg-red-500/10';
  } else if (score <= 9) {
    decision = 'Achat possible avec prudence';
    decisionColor = 'text-amber-500';
    decisionBg = 'border-amber-500/50 bg-amber-500/10';
  } else {
    if (mandatoryMissing.length === 0) {
      decision = 'Configuration forte - Achat valide';
      decisionColor = 'text-emerald-500';
      decisionBg = 'border-emerald-500/50 bg-emerald-500/10';
    } else {
      decision = 'Achat possible avec prudence';
      decisionColor = 'text-amber-500';
      decisionBg = 'border-amber-500/50 bg-amber-500/10';
    }
  }

  const tfScores = CRITERIA_BY_TF.map(g => {
    const checked = g.items.filter(i => checklist[i.key]).length;
    return { tf: g.tf, icon: g.icon, checked, total: g.items.length, pct: g.items.length > 0 ? Math.round((checked / g.items.length) * 100) : 0 };
  });

  return (
    <div className={embedded ? '' : 'space-y-4'}>
      {/* Score + Decision display */}
      <div className="flex flex-col sm:flex-row sm:items-center gap-4 mb-4">
        <div className={`text-4xl font-bold ${score >= 10 ? 'text-emerald-500' : score >= 7 ? 'text-amber-500' : 'text-red-500'}`}>
          {score}/{TOTAL}
        </div>
        <div className="flex-1">
          <p className={`text-lg font-semibold ${decisionColor}`}>{decision}</p>
          <p className="text-xs text-muted-foreground">{score} critere{score > 1 ? 's' : ''} valide{score > 1 ? 's' : ''} sur {TOTAL} | {activeExclusions} exclusion{activeExclusions > 1 ? 's' : ''} active{activeExclusions > 1 ? 's' : ''}</p>
        </div>
      </div>

      {/* Per-TF mini score bars */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-5">
        {tfScores.map(tf => (
          <div key={tf.tf} className="p-2.5 rounded-lg bg-accent/50">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-xs font-medium text-muted-foreground">{tf.tf}</span>
              <span className={`text-xs font-bold ${tf.pct === 100 ? 'text-emerald-500' : tf.pct >= 50 ? 'text-amber-500' : 'text-red-500'}`}>{tf.checked}/{tf.total}</span>
            </div>
            <div className="w-full h-1.5 bg-accent rounded-full overflow-hidden">
              <div className={`h-full rounded-full transition-all duration-500 ${tf.pct === 100 ? 'bg-emerald-500' : tf.pct >= 50 ? 'bg-amber-500' : 'bg-red-500'}`} style={{ width: `${tf.pct}%` }} />
            </div>
          </div>
        ))}
      </div>

      {/* EXCLUSION CONDITIONS */}
      {showExclusions && (
        <div className="mb-5">
          <div className="flex items-center gap-2 mb-3">
            <XCircle className="w-4 h-4 text-red-500" />
            <h3 className="text-sm font-semibold text-red-500">Conditions d'exclusion - Ne pas entrer si l'une de ces conditions est active</h3>
          </div>
          <div className="space-y-2">
            {EXCLUSION_CRITERIA.map(c => {
              const isActive = !!exclusions?.[c.key];
              return (
                <Card key={c.key} className={`border-l-4 ${isActive ? 'border-l-red-500 bg-red-500/5' : 'border-l-transparent'} hover:bg-accent/50 transition-colors`}>
                  <CardContent className="p-3 flex items-start gap-3">
                    <Checkbox
                      checked={isActive}
                      onCheckedChange={(v) => onExclusionChange?.(c.key, !!v)}
                      className="data-[state=checked]:bg-red-600 data-[state=checked]:border-red-600 mt-0.5"
                    />
                    <Label className={`text-sm cursor-pointer flex-1 ${isActive ? 'text-red-500 font-medium' : 'text-muted-foreground'}`} onClick={() => onExclusionChange?.(c.key, !isActive)}>
                      {c.label}
                    </Label>
                  </CardContent>
                </Card>
              );
            })}
          </div>
          {activeExclusions > 0 && (
            <div className="mt-2 p-3 rounded-lg border border-red-500/30 bg-red-500/5">
              <p className="text-sm font-medium text-red-500">{activeExclusions} condition{activeExclusions > 1 ? 's' : ''} d'exclusion active{activeExclusions > 1 ? 's' : ''} - L'entree est interdite meme si le score est eleve.</p>
            </div>
          )}
        </div>
      )}

      {/* SIGNAL CRITERIA BY TIMEFRAME */}
      <div className="space-y-4">
        {CRITERIA_BY_TF.map(group => {
          const groupScore = group.items.filter(i => checklist[i.key]).length;
          return (
            <div key={group.tf}>
              <div className="flex items-center gap-2 mb-2">
                <span className={`inline-flex items-center justify-center w-8 h-8 rounded-lg text-[10px] font-bold ${group.tf === 'RISQUE' ? 'bg-blue-500/20 text-blue-500' : 'bg-emerald-500/20 text-emerald-500'}`}>
                  {group.icon}
                </span>
                <h3 className="text-sm font-semibold">{group.group}</h3>
                <span className="text-xs text-muted-foreground ml-auto">{groupScore}/{group.items.length}</span>
              </div>
              <div className="space-y-1.5 ml-2">
                {group.items.map(c => (
                  <Card key={c.key} className={`border-l-4 ${checklist[c.key] ? 'border-l-emerald-500' : c.mandatory ? 'border-l-red-500/50' : 'border-l-transparent'} hover:bg-accent/50 transition-colors`}>
                    <CardContent className="p-3 flex items-start gap-3">
                      <div className="flex items-center gap-2 min-w-[24px]">
                        <Checkbox
                          checked={!!checklist[c.key]}
                          onCheckedChange={(v) => onChange(c.key, !!v)}
                          className="data-[state=checked]:bg-emerald-600 data-[state=checked]:border-emerald-600"
                        />
                      </div>
                      <div className="flex-1">
                        <Label className={`text-sm cursor-pointer ${checklist[c.key] ? 'line-through text-muted-foreground' : ''}`} onClick={() => onChange(c.key, !checklist[c.key])}>
                          {c.label}
                        </Label>
                      </div>
                      {c.mandatory && (
                        <Badge variant="outline" className="text-[10px] text-red-500 border-red-500/30 shrink-0">Obligatoire</Badge>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* Mandatory alerts */}
      {mandatoryMissing.length > 0 && activeExclusions === 0 && (
        <div className="mt-4 p-3 rounded-lg border border-red-500/30 bg-red-500/5">
          <div className="flex items-center gap-2 mb-2">
            <AlertTriangle className="w-4 h-4 text-red-500" />
            <p className="text-sm font-medium text-red-500">Conditions obligatoires manquantes</p>
          </div>
          <ul className="list-disc list-inside text-sm text-red-500/80 space-y-0.5">
            {mandatoryMissing.map(k => {
              const c = ALL_CRITERIA.find(x => x.key === k);
              return <li key={k}>{MANDATORY_MISSING_LABELS[k] || k}</li>;
            })}
          </ul>
          <p className="text-xs text-muted-foreground mt-2">Meme avec un score eleve, l'absence d'une condition obligatoire empeche la validation.</p>
        </div>
      )}

      {/* Decision legend */}
      <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
        <div className="p-2 rounded bg-red-500/10 border border-red-500/20"><span className="text-red-500 font-medium">0-6</span><br />Ne pas entrer</div>
        <div className="p-2 rounded bg-amber-500/10 border border-amber-500/20"><span className="text-amber-500 font-medium">7-9</span><br />Achat possible</div>
        <div className="p-2 rounded bg-emerald-500/10 border border-emerald-500/20"><span className="text-emerald-500 font-medium">10-13</span><br />Configuration forte</div>
        <div className="p-2 rounded bg-red-500/10 border border-red-500/20"><span className="text-red-500 font-medium">Exc.</span><br />Exclusion active</div>
      </div>
    </div>
  );
}
