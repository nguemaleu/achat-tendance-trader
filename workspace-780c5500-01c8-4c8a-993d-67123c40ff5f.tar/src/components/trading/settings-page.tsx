'use client';

import { useEffect, useState } from 'react';
import { useAppStore, apiHeaders } from '@/store/app-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';

const CURRENCIES = ['USD', 'CAD', 'EUR', 'GBP'];
const ASSET_OPTIONS = ['XAU/USD', 'EUR/USD', 'GBP/USD', 'NASDAQ', 'USD/JPY', 'USD/CAD', 'AUD/USD', 'S&P 500', 'DAX'];
const SESSION_OPTIONS = ['Londres', 'New York', 'Asie', 'Overlap Londres/NY'];
const TF_OPTIONS = ['M5', 'M15', 'M30', 'H1', 'H4', 'D1'];

interface Settings {
  id: string;
  initialCapital: number;
  currentCapital: number;
  accountCurrency: string;
  maxRiskPerTrade: number;
  dailyLossLimit: number;
  maxTradesPerDay: number;
  favoriteAssets: string;
  favoriteSessions: string;
  favoriteTimeframes: string;
  monthlyGoal: number;
  darkMode: boolean;
}

export function SettingsPage() {
  const { demoUserId } = useAppStore();
  const [settings, setSettings] = useState<Settings | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!demoUserId) return;
    let cancelled = false;
    (async () => {
      const res = await fetch('/api/settings', { headers: apiHeaders(demoUserId) });
      if (!cancelled) {
        setSettings(await res.json());
        setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [demoUserId]);

  async function save() {
    if (!settings) return;
    await fetch('/api/settings', {
      method: 'PUT', headers: apiHeaders(demoUserId), body: JSON.stringify(settings),
    });
    toast.success('Paramètres enregistrés');
  }

  function update(field: keyof Settings, value: string | number | boolean) {
    if (!settings) return;
    setSettings({ ...settings, [field]: value });
  }

  if (loading || !settings) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin w-8 h-8 border-2 border-emerald-500 border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-2xl font-bold">Paramètres</h2>
        <p className="text-muted-foreground text-sm mt-1">Configurez votre profil de trading</p>
      </div>

      {/* Account settings */}
      <Card>
        <CardHeader><CardTitle className="text-base">Compte</CardTitle></CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div><Label>Capital initial ($)</Label><Input type="number" step="any" value={settings.initialCapital} onChange={e => update('initialCapital', parseFloat(e.target.value) || 0)} /></div>
          <div><Label>Capital actuel ($)</Label><Input type="number" step="any" value={settings.currentCapital} onChange={e => update('currentCapital', parseFloat(e.target.value) || 0)} /></div>
          <div><Label>Devise du compte</Label><Select value={settings.accountCurrency} onValueChange={v => update('accountCurrency', v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{CURRENCIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent></Select></div>
          <div><Label>Objectif mensuel ($)</Label><Input type="number" step="any" value={settings.monthlyGoal} onChange={e => update('monthlyGoal', parseFloat(e.target.value) || 0)} /></div>
        </CardContent>
      </Card>

      {/* Risk settings */}
      <Card>
        <CardHeader><CardTitle className="text-base">Gestion du risque</CardTitle></CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div><Label>Risque max par trade (%)</Label><Input type="number" step="0.1" min="0.1" max="5" value={settings.maxRiskPerTrade} onChange={e => update('maxRiskPerTrade', parseFloat(e.target.value) || 0)} /></div>
          <div><Label>Limite de pertes quotidienne (%)</Label><Input type="number" step="0.1" value={settings.dailyLossLimit} onChange={e => update('dailyLossLimit', parseFloat(e.target.value) || 0)} /></div>
          <div><Label>Nombre max de trades / jour</Label><Input type="number" min="1" max="20" value={settings.maxTradesPerDay} onChange={e => update('maxTradesPerDay', parseInt(e.target.value) || 1)} /></div>
        </CardContent>
      </Card>

      {/* Favorites */}
      <Card>
        <CardHeader><CardTitle className="text-base">Favoris</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label className="mb-2 block">Actifs favoris (séparés par des virgules)</Label>
            <Input value={settings.favoriteAssets} onChange={e => update('favoriteAssets', e.target.value)} />
          </div>
          <div>
            <Label className="mb-2 block">Sessions favorites (séparées par des virgules)</Label>
            <Input value={settings.favoriteSessions} onChange={e => update('favoriteSessions', e.target.value)} />
          </div>
          <div>
            <Label className="mb-2 block">Unités de temps favorites (séparées par des virgules)</Label>
            <Input value={settings.favoriteTimeframes} onChange={e => update('favoriteTimeframes', e.target.value)} />
          </div>
        </CardContent>
      </Card>

      {/* Appearance */}
      <Card>
        <CardHeader><CardTitle className="text-base">Apparence</CardTitle></CardHeader>
        <CardContent>
          <div className="flex items-center gap-3">
            <Switch checked={settings.darkMode} onCheckedChange={v => update('darkMode', v)} />
            <Label>Mode sombre</Label>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button onClick={save} className="bg-emerald-600 hover:bg-emerald-700">Enregistrer les paramètres</Button>
      </div>
    </div>
  );
}
