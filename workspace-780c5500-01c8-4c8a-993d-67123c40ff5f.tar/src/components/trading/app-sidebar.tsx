'use client';

import { useAppStore, type Page } from '@/store/app-store';
import { cn } from '@/lib/utils';
import {
  LayoutDashboard, Search, PlusCircle, CheckSquare, Calculator,
  BookOpen, CalendarDays, BarChart3, Shield, Settings,
  TrendingUp, X, Bell,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useEffect, useState } from 'react';

const navItems: { page: Page; label: string; icon: React.ElementType; special?: boolean }[] = [
  { page: 'dashboard', label: 'Tableau de bord', icon: LayoutDashboard },
  { page: 'opportunities', label: 'Opportunités', icon: Search },
  { page: 'new-analysis', label: 'Nouvelle analyse', icon: PlusCircle, special: true },
  { page: 'checklist', label: 'Checklist', icon: CheckSquare },
  { page: 'risk-calculator', label: 'Calculateur de risque', icon: Calculator },
  { page: 'trades', label: 'Trades', icon: BookOpen },
  { page: 'journal', label: 'Journal quotidien', icon: CalendarDays },
  { page: 'statistics', label: 'Statistiques', icon: BarChart3 },
  { page: 'rules', label: 'Règles', icon: Shield },
  { page: 'settings', label: 'Paramètres', icon: Settings },
];

export function AppSidebar() {
  const { currentPage, setCurrentPage, sidebarOpen, setSidebarOpen } = useAppStore();
  const [alertCount, setAlertCount] = useState(0);
  const [userId, setUserId] = useState('');

  useEffect(() => {
    async function loadUser() {
      try {
        const res = await fetch('/api/opportunities');
        const data = await res.json();
        if (data.length > 0) {
          const id = data[0].userId;
          setUserId(id);
          useAppStore.getState().setDemoUserId(id);

          // Fetch unread alerts
          const alertRes = await fetch('/api/alerts', { headers: { 'x-user-id': id } });
          const alerts = await alertRes.json();
          setAlertCount((alerts || []).filter((a: { isRead: boolean }) => !a.isRead).length);
        }
      } catch {}
    }
    loadUser();
  }, []);

  function navigate(page: Page) {
    setCurrentPage(page);
    setSidebarOpen(false);
  }

  return (
    <>
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <aside
        className={cn(
          'fixed top-0 left-0 z-50 h-full w-64 bg-card border-r border-border flex flex-col transition-transform duration-300 lg:translate-x-0 lg:static lg:z-auto',
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        )}
      >
        {/* Logo */}
        <div className="flex items-center justify-between p-4 border-b border-border">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-sm font-bold leading-tight">Achat Tendance</h1>
              <p className="text-[10px] text-muted-foreground leading-tight">Trader</p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden h-8 w-8"
            onClick={() => setSidebarOpen(false)}
          >
            <X className="w-4 h-4" />
          </Button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto py-2 px-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.page;
            return (
              <button
                key={item.page}
                onClick={() => navigate(item.page)}
                className={cn(
                  'w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors mb-0.5',
                  isActive
                    ? 'bg-emerald-600/15 text-emerald-500 font-medium'
                    : 'text-muted-foreground hover:bg-accent hover:text-foreground',
                  item.special && !isActive && 'text-emerald-500 hover:text-emerald-400 hover:bg-emerald-600/10'
                )}
              >
                <Icon className={cn('w-4 h-4', item.special && 'w-5 h-5')} />
                <span>{item.label}</span>
                {item.page === 'dashboard' && alertCount > 0 && (
                  <Badge variant="destructive" className="ml-auto text-[10px] px-1.5 py-0">
                    {alertCount}
                  </Badge>
                )}
              </button>
            );
          })}
        </nav>

        {/* Footer warning */}
        <div className="p-3 border-t border-border">
          <div className="bg-amber-500/10 border border-amber-500/20 rounded-lg p-2.5">
            <p className="text-[10px] text-amber-500/80 leading-relaxed">
              Outil de planification uniquement. Ne garantit aucun résultat. Le trading comporte des risques importants de perte.
            </p>
          </div>
          {userId && (
            <div className="flex items-center gap-2 mt-2">
              <div className="w-2 h-2 rounded-full bg-emerald-500" />
              <span className="text-[10px] text-muted-foreground">Mode démonstration</span>
            </div>
          )}
        </div>
      </aside>
    </>
  );
}