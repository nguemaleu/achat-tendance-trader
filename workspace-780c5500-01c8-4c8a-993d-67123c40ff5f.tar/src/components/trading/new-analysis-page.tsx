'use client';

import { useState, useEffect, useMemo } from 'react';
import { useAppStore, apiHeaders } from '@/store/app-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { ChecklistPanel, EXCLUSION_CRITERIA } from './checklist-panel';
import { RiskCalculatorPanel } from './risk-calculator-panel';
import { toast } from 'sonner';
import {
  ChevronLeft, ChevronRight, Check, XCircle, TrendingUp, TrendingDown, Minus, Save, AlertTriangle,
} from 'lucide-react';

const ASSETS = ['XAU/USD', 'EUR/USD', 'GBP/USD', 'NASDAQ', 'USD/JPY', 'USD/CAD', 'AUD/USD', 'S&P 500', 'DAX'];
const CATEGORIES = ['Devise', 'Indice', 'Matiere', 'Crypto'];
const SESSIONS = ['Londres', 'New York', 'Asie', 'Overlap Londres/NY'];
const TIMEFRAMES = ['M5', 'M15', 'M30', 'H1', 'H4', 'D1'];
const TRENDS = ['Haussier', 'Baissier', 'Neutre'];
const EMA_STATUSES = ['Au-dessus (alignees haussier)', 'Au-dessus (desalignees)', 'Au-dessus (en convergence)', 'En-dessous (alignees baissier)', 'En-dessous (desalignees)', 'Entremelees (pas de signal)', 'Plates (range)'];
const M15_SITUATIONS = ['Retour sur support confirmee', 'Pullback dans la zone', 'Bougie de confirmation en cours', 'Attente confirmation', 'Zone non atteinte', 'Configuration invalide'];

const STEPS = [
  { title: 'Actif et marche', icon: '1' },
  { title: 'Tendance multi-TF', icon: '2' },
  { title: 'Niveaux de prix', icon: '3' },
  { title: 'Checklist', icon: '4' },
  { title: 'Validation', icon: '5' },
];

function TrendMatrix({ trendH4, trendH1, trendM15 }: { trendH4: string; trendH1: string; trendM15: string }) {
  const cells: { tf: string; trend: string; color: string }[][] = [
    [
      { tf: 'H4', trend: trendH4, color: trendH4 === 'Haussier' ? 'bg-emerald-500/20 text-emerald-500' : trendH4 === 'Baissier' ? 'bg-red-500/20 text-red-500' : 'bg-accent/50' },
      { tf: 'H1', trend: trendH1, color: trendH1 === 'Haussier' ? 'bg-emerald-500/20 text-emerald-500' : trendH1 === 'Baissier' ? 'bg-red-500/20 text-red-500' : 'bg-accent/50' },
      { tf: 'M15', trend: trendM15, color: trendM15 === 'Haussier' ? 'bg-emerald-500/20 text-emerald-500' : trendM15 === 'Baissier' ? 'bg-red-500/20 text-red-500' : 'bg-accent/50' },
    ],
  ];

  let alignment = '';
  let alignColor = 'text-muted-foreground';
  if (trendH4 && trendH1 && trendM15) {
    if (trendH4 === 'Haussier' && trendH1 === 'Haussier') {
      alignment = 'Alignement haussier H4/H1';
      alignColor = 'text-emerald-500';
    } else if (trendH4 === 'Baissier' && trendH1 === 'Baissier') {
      alignment = 'Alignement baissier H4/H1';
      alignColor = 'text-red-500';
    } else {
      alignment = 'Desalignement - Prudence';
      alignColor = 'text-amber-500';
    }
  }

  return (
    <div className="space-y-3">
      <h4 className="text-sm font-semibold">Matrice des tendances</h4>
      <div className="grid grid-cols-3 gap-2">
        {cells[0].map(cell => (
          <div key={cell.tf} className={`p-3 rounded-lg text-center ${cell.color}`}>
            <p className="text-xs text-muted-foreground mb-1">{cell.tf}</p>
            <p className="text-sm font-bold flex items-center justify-center gap-1">
              {cell.trend === 'Haussier' && <TrendingUp className="w-4 h-4" />}
              {cell.trend === 'Baissier' && <TrendingDown className="w-4 h-4" />}
              {cell.trend === 'Neutre' && <Minus className="w-4 h-4" />}
              {cell.trend || '-'}
            </p>
          </div>
        ))}
      </div>
      {alignment && (
        <div className={`text-sm font-medium ${alignColor}`}>{alignment}</div>
      )}
    </div>
  );
}

export function NewAnalysisPage() {
  const { demoUserId, setCurrentPage } = useAppStore();
  const [step, setStep] = useState(0);
  const [saving, setSaving] = useState(false);

  // Step 1: Asset and market
  const [asset, setAsset] = useState('XAU/USD');
  const [marketCategory, setMarketCategory] = useState('Devise');
  const [tradingSession, setTradingSession] = useState('Londres');
  const [primaryTimeframe, setPrimaryTimeframe] = useState('H4');
  const [entryTimeframe, setEntryTimeframe] = useState('M15');

  // Step 2: Multi-TF trend
  const [trendH4, setTrendH4] = useState('');
  const [trendH1, setTrendH1] = useState('');
  const [trendM15, setTrendM15] = useState('');
  const [emaH4Status, setEmaH4Status] = useState('');
  const [emaH1Status, setEmaH1Status] = useState('');
  const [m15Situation, setM15Situation] = useState('');

  // Step 3: Price levels
  const [currentPrice, setCurrentPrice] = useState('');
  const [mainSupport, setMainSupport] = useState('');
  const [mainResistance, setMainResistance] = useState('');
  const [plannedEntry, setPlannedEntry] = useState('');
  const [plannedStopLoss, setPlannedStopLoss] = useState('');
  const [tp1, setTp1] = useState('');
  const [tp2, setTp2] = useState('');

  // Step 4: Checklist
  const [checklist, setChecklist] = useState<Record<string, boolean>>({});
  const [exclusions, setExclusions] = useState<Record<string, boolean>>({});

  // Settings for risk calculator
  const [userCapital, setUserCapital] = useState(10000);

  useEffect(() => {
    if (!demoUserId) return;
    (async () => {
      try {
        const res = await fetch('/api/settings', { headers: apiHeaders(demoUserId) });
        const data = await res.json();
        if (data?.currentCapital) setUserCapital(data.currentCapital);
      } catch {}
    })();
  }, [demoUserId]);

  // Computed values
  const activeExclusions = useMemo(() => {
    return Object.entries(exclusions).filter(([, v]) => v).length;
  }, [exclusions]);

  const score = useMemo(() => {
    return Object.values(checklist).filter(Boolean).length;
  }, [checklist]);

  const entry = parseFloat(plannedEntry) || 0;
  const sl = parseFloat(plannedStopLoss) || 0;
  const tp1Val = parseFloat(tp1) || 0;
  const rr = entry && sl && tp1Val ? Math.abs(tp1Val - entry) / Math.abs(entry - sl) : 0;

  // Decision logic: exclusions override score
  const decision = useMemo(() => {
    if (activeExclusions > 0) {
      return { text: 'NE PAS ENTRER - Exclusion(s) active(s)', color: 'text-red-500', bg: 'border-red-500/50 bg-red-500/10' };
    }
    if (score <= 6) {
      return { text: 'Ne pas entrer', color: 'text-red-500', bg: 'border-red-500/50 bg-red-500/10' };
    }
    if (score <= 9) {
      return { text: 'Achat possible avec prudence', color: 'text-amber-500', bg: 'border-amber-500/50 bg-amber-500/10' };
    }
    // score >= 10
    return { text: 'Configuration forte - Achat valide', color: 'text-emerald-500', bg: 'border-emerald-500/50 bg-emerald-500/10' };
  }, [activeExclusions, score]);

  const canProceed = useMemo(() => {
    switch (step) {
      case 0: return !!asset;
      case 1: return !!trendH4;
      case 2: return !!currentPrice;
      case 3: return true;
      case 4: return true;
      default: return true;
    }
  }, [step, asset, trendH4, currentPrice]);

  async function saveAnalysis() {
    if (!demoUserId) return;
    setSaving(true);
    try {
      const h = apiHeaders(demoUserId);
      const body = {
        name: `${asset} - ${new Date().toLocaleDateString('fr-FR')}`,
        asset,
        marketCategory,
        tradingSession,
        primaryTimeframe,
        entryTimeframe,
        trendH4,
        trendH1,
        currentPrice: parseFloat(currentPrice) || null,
        mainSupport: parseFloat(mainSupport) || null,
        mainResistance: parseFloat(mainResistance) || null,
        plannedEntry: parseFloat(plannedEntry) || null,
        plannedStopLoss: parseFloat(plannedStopLoss) || null,
        takeProfit1: parseFloat(tp1) || null,
        takeProfit2: parseFloat(tp2) || null,
        riskRewardRatio: rr || null,
        validationScore: score,
        checklistJson: JSON.stringify({ checklist, exclusions }),
        status: activeExclusions > 0 ? 'Annulee' : score >= 10 ? 'Validee' : 'En cours',
        comments: `Decision: ${decision.text}. Score: ${score}/13. R/R: ${rr ? rr.toFixed(2) : '-'}:1`,
      };
      await fetch('/api/opportunities', { method: 'POST', headers: h, body: JSON.stringify(body) });
      toast.success('Analyse enregistree');
      setCurrentPage('opportunities');
    } catch {
      toast.error('Erreur lors de l&apos;enregistrement');
    } finally {
      setSaving(false);
    }
  }

  function toggleChecklist(key: string, value: boolean) {
    setChecklist(prev => ({ ...prev, [key]: value }));
  }

  function toggleExclusion(key: string, value: boolean) {
    setExclusions(prev => ({ ...prev, [key]: value }));
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold">Nouvelle analyse</h2>
        <p className="text-muted-foreground text-sm mt-1">Analysez une opportunite de trading en 5 etapes</p>
      </div>

      {/* Progress bar */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          {STEPS.map((s, i) => (
            <button
              key={i}
              onClick={() => i < step && setStep(i)}
              className={`flex items-center gap-2 text-xs font-medium transition-colors ${i === step ? 'text-emerald-500' : i < step ? 'text-foreground cursor-pointer' : 'text-muted-foreground'}`}
            >
              <span className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold ${i === step ? 'bg-emerald-600 text-white' : i < step ? 'bg-emerald-500/20 text-emerald-500' : 'bg-accent/50 text-muted-foreground'}`}>
                {i < step ? <Check className="w-3.5 h-3.5" /> : s.icon}
              </span>
              <span className="hidden sm:inline">{s.title}</span>
            </button>
          ))}
        </div>
        <Progress value={((step + 1) / STEPS.length) * 100} className="h-1.5" />
      </div>

      {/* Step 1: Asset and Market */}
      {step === 0 && (
        <Card>
          <CardHeader><CardTitle className="text-base">Etape 1 - Actif et marche</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Actif</Label>
                <Select value={asset} onValueChange={setAsset}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{ASSETS.map(a => <SelectItem key={a} value={a}>{a}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label>Categorie de marche</Label>
                <Select value={marketCategory} onValueChange={setMarketCategory}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{CATEGORIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label>Session de trading</Label>
                <Select value={tradingSession} onValueChange={setTradingSession}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{SESSIONS.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label>Unite de temps principale</Label>
                <Select value={primaryTimeframe} onValueChange={setPrimaryTimeframe}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{TIMEFRAMES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label>Unite de temps d&apos;entree</Label>
                <Select value={entryTimeframe} onValueChange={setEntryTimeframe}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{TIMEFRAMES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Step 2: Multi-TF Trend */}
      {step === 1 && (
        <Card>
          <CardHeader><CardTitle className="text-base">Etape 2 - Tendance multi-TF</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label>Tendance H4</Label>
                <Select value={trendH4} onValueChange={setTrendH4}>
                  <SelectTrigger><SelectValue placeholder="Selectionner" /></SelectTrigger>
                  <SelectContent>
                    {TRENDS.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Tendance H1</Label>
                <Select value={trendH1 || undefined} onValueChange={setTrendH1}>
                  <SelectTrigger><SelectValue placeholder="Selectionner" /></SelectTrigger>
                  <SelectContent>
                    {TRENDS.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Tendance M15</Label>
                <Select value={trendM15 || undefined} onValueChange={setTrendM15}>
                  <SelectTrigger><SelectValue placeholder="Selectionner" /></SelectTrigger>
                  <SelectContent>
                    {TRENDS.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="border-t border-border pt-4 space-y-4">
              <h4 className="text-sm font-semibold">Statut des EMA</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label>EMA H4</Label>
                  <Select value={emaH4Status || undefined} onValueChange={setEmaH4Status}>
                    <SelectTrigger><SelectValue placeholder="Selectionner" /></SelectTrigger>
                    <SelectContent>
                      {EMA_STATUSES.map(e => <SelectItem key={e} value={e}>{e}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>EMA H1</Label>
                  <Select value={emaH1Status || undefined} onValueChange={setEmaH1Status}>
                    <SelectTrigger><SelectValue placeholder="Selectionner" /></SelectTrigger>
                    <SelectContent>
                      {EMA_STATUSES.map(e => <SelectItem key={e} value={e}>{e}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            <div className="border-t border-border pt-4">
              <div>
                <Label>Situation M15</Label>
                <Select value={m15Situation || undefined} onValueChange={setM15Situation}>
                  <SelectTrigger><SelectValue placeholder="Selectionner" /></SelectTrigger>
                  <SelectContent>
                    {M15_SITUATIONS.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Quick trend summary */}
            {trendH4 && (
              <div className="border-t border-border pt-4">
                <TrendMatrix trendH4={trendH4} trendH1={trendH1} trendM15={trendM15} />
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Step 3: Price Levels */}
      {step === 2 && (
        <Card>
          <CardHeader><CardTitle className="text-base">Etape 3 - Niveaux de prix</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Prix actuel</Label>
                <Input type="number" step="any" value={currentPrice} onChange={e => setCurrentPrice(e.target.value)} />
              </div>
              <div>
                <Label>Support principal</Label>
                <Input type="number" step="any" value={mainSupport} onChange={e => setMainSupport(e.target.value)} />
              </div>
              <div>
                <Label>Resistance principale</Label>
                <Input type="number" step="any" value={mainResistance} onChange={e => setMainResistance(e.target.value)} />
              </div>
              <div>
                <Label>Entree planifiee</Label>
                <Input type="number" step="any" value={plannedEntry} onChange={e => setPlannedEntry(e.target.value)} />
              </div>
              <div>
                <Label>Stop-loss</Label>
                <Input type="number" step="any" value={plannedStopLoss} onChange={e => setPlannedStopLoss(e.target.value)} />
              </div>
              <div>
                <Label>Take Profit 1</Label>
                <Input type="number" step="any" value={tp1} onChange={e => setTp1(e.target.value)} />
              </div>
              <div>
                <Label>Take Profit 2</Label>
                <Input type="number" step="any" value={tp2} onChange={e => setTp2(e.target.value)} />
              </div>
            </div>

            {/* Quick summary */}
            {entry && sl && tp1Val && (
              <div className="grid grid-cols-3 gap-3 pt-2 border-t border-border">
                <div className="p-3 rounded-lg bg-accent/50 text-center">
                  <p className="text-xs text-muted-foreground">Distance SL</p>
                  <p className="text-lg font-bold">{Math.abs(entry - sl).toFixed(1)}</p>
                </div>
                <div className="p-3 rounded-lg bg-accent/50 text-center">
                  <p className="text-xs text-muted-foreground">Distance TP1</p>
                  <p className="text-lg font-bold">{Math.abs(tp1Val - entry).toFixed(1)}</p>
                </div>
                <div className={`p-3 rounded-lg text-center ${rr >= 2 ? 'bg-emerald-500/10' : 'bg-red-500/10'}`}>
                  <p className="text-xs text-muted-foreground">Ratio R/R</p>
                  <p className={`text-lg font-bold ${rr >= 2 ? 'text-emerald-500' : 'text-red-500'}`}>{rr.toFixed(2)}:1</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Step 4: Checklist */}
      {step === 3 && (
        <Card>
          <CardHeader><CardTitle className="text-base">Etape 4 - Checklist</CardTitle></CardHeader>
          <CardContent>
            <ChecklistPanel
              checklist={checklist}
              exclusions={exclusions}
              onChange={toggleChecklist}
              onExclusionChange={toggleExclusion}
              embedded
            />
          </CardContent>
        </Card>
      )}

      {/* Step 5: Validation */}
      {step === 4 && (
        <div className="space-y-4">
          {/* Decision banner */}
          <div className={`p-4 rounded-lg border-2 ${decision.bg}`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {activeExclusions > 0 ? (
                  <XCircle className="w-6 h-6 text-red-500" />
                ) : score >= 10 ? (
                  <Check className="w-6 h-6 text-emerald-500" />
                ) : (
                  <AlertTriangle className="w-6 h-6 text-amber-500" />
                )}
                <div>
                  <p className={`text-lg font-bold ${decision.color}`}>{decision.text}</p>
                  <p className="text-sm text-muted-foreground">Score: {score}/13 | R/R: {rr ? `${rr.toFixed(2)}:1` : '-'} | Exclusions: {activeExclusions}</p>
                </div>
              </div>
              <div className={`text-3xl font-bold ${score >= 10 ? 'text-emerald-500' : score >= 7 ? 'text-amber-500' : 'text-red-500'}`}>
                {score}/13
              </div>
            </div>
          </div>

          {/* Exclusions warning */}
          {activeExclusions > 0 && (
            <Alert variant="destructive">
              <AlertTriangle className="w-4 h-4" />
              <AlertDescription>
                {activeExclusions} exclusion(s) active(s). L&apos;entree est interdite meme si le score est eleve.
              </AlertDescription>
            </Alert>
          )}

          {/* Trend matrix summary */}
          {trendH4 && (
            <Card>
              <CardContent className="p-4">
                <TrendMatrix trendH4={trendH4} trendH1={trendH1} trendM15={trendM15} />
              </CardContent>
            </Card>
          )}

          {/* Price summary */}
          <Card>
            <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Resume des niveaux</CardTitle></CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div className="p-2 rounded bg-accent/50">
                  <p className="text-xs text-muted-foreground">Actif</p>
                  <p className="font-medium font-mono">{asset}</p>
                </div>
                {currentPrice && <div className="p-2 rounded bg-accent/50"><p className="text-xs text-muted-foreground">Prix</p><p className="font-medium">{currentPrice}</p></div>}
                {mainSupport && <div className="p-2 rounded bg-emerald-500/10"><p className="text-xs text-muted-foreground">Support</p><p className="font-medium text-emerald-500">{mainSupport}</p></div>}
                {mainResistance && <div className="p-2 rounded bg-red-500/10"><p className="text-xs text-muted-foreground">Resistance</p><p className="font-medium text-red-500">{mainResistance}</p></div>}
                {plannedEntry && <div className="p-2 rounded bg-accent/50"><p className="text-xs text-muted-foreground">Entree</p><p className="font-medium">{plannedEntry}</p></div>}
                {plannedStopLoss && <div className="p-2 rounded bg-red-500/10"><p className="text-xs text-muted-foreground">SL</p><p className="font-medium text-red-500">{plannedStopLoss}</p></div>}
                {tp1 && <div className="p-2 rounded bg-emerald-500/10"><p className="text-xs text-muted-foreground">TP1</p><p className="font-medium text-emerald-500">{tp1}</p></div>}
                {tp2 && <div className="p-2 rounded bg-emerald-500/10"><p className="text-xs text-muted-foreground">TP2</p><p className="font-medium text-emerald-500">{tp2}</p></div>}
              </div>
            </CardContent>
          </Card>

          {/* Risk calculator */}
          <RiskCalculatorPanel
            capital={userCapital}
            entryPrice={plannedEntry}
            stopLoss={plannedStopLoss}
            takeProfit1={tp1}
            takeProfit2={tp2}
            asset={asset}
            embedded
          />
        </div>
      )}

      {/* Navigation buttons */}
      <div className="flex items-center justify-between pt-2">
        <Button
          variant="outline"
          onClick={() => setStep(s => s - 1)}
          disabled={step === 0}
        >
          <ChevronLeft className="w-4 h-4 mr-2" />Precedent
        </Button>

        {step < STEPS.length - 1 ? (
          <Button
            onClick={() => setStep(s => s + 1)}
            disabled={!canProceed}
            className="bg-emerald-600 hover:bg-emerald-700"
          >
            Suivant<ChevronRight className="w-4 h-4 ml-2" />
          </Button>
        ) : (
          <Button
            onClick={saveAnalysis}
            disabled={saving}
            className="bg-emerald-600 hover:bg-emerald-700"
          >
            <Save className="w-4 h-4 mr-2" />{saving ? 'Enregistrement...' : 'Enregistrer l&apos;analyse'}
          </Button>
        )}
      </div>
    </div>
  );
}
