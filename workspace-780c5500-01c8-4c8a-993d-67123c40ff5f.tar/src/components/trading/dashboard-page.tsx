'use client';

import { useEffect, useState } from 'react';
import { useAppStore, apiHeaders } from '@/store/app-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine, Cell,
} from 'recharts';
import {
  DollarSign, Target, TrendingUp, TrendingDown, AlertTriangle, Flame, Zap, BarChart3, Eye,
} from 'lucide-react';

interface Stats {
  currentCapital: number;
  totalTrades: number;
  winCount: number;
  lossCount: number;
  openTrades: number;
  winRate: number;
  netProfit: number;
  avgWin: number;
  avgLoss: number;
  profitFactor: number;
  expectancy: number;
  maxDrawdown: number;
  todayResult: number;
  weekResult: number;
  monthResult: number;
  streak: number;
  streakType: string | null;
  planRate: number;
  equityCurve: { date: string; equity: number }[];
  weekPnl: { week: string; pnl: number }[];
  gainLossRatio: number;
}

interface Opportunity {
  id: string;
  asset: string;
  name: string;
  trendH4: string;
  trendH1: string;
  validationScore: number;
  status: string;
  currentPrice: number | null;
  riskRewardRatio: number | null;
  analysisDate: string;
}

interface Trade {
  id: string;
  asset: string;
  direction: string;
  entryDate: string | null;
  entryPrice: number | null;
  initialStopLoss: number | null;
  netResult: number | null;
  status: string;
}

export function DashboardPage() {
  const { demoUserId, setCurrentPage } = useAppStore();
  const [stats, setStats] = useState<Stats | null>(null);
  const [opportunities, setOpportunities] = useState<Opportunity[]>([]);
  const [openTrades, setOpenTrades] = useState<Trade[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!demoUserId) return;
    let cancelled = false;
    const h = apiHeaders(demoUserId);

    (async () => {
      const [statsRes, oppRes, tradesRes] = await Promise.all([
        fetch('/api/stats', { headers: h }),
        fetch('/api/opportunities', { headers: h }),
        fetch('/api/trades?status=Ouvert', { headers: h }),
      ]);
      if (!cancelled) {
        const statsData = await statsRes.json();
        const oppData = await oppRes.json();
        const tradesData = await tradesRes.json();
        setStats(statsData);
        setOpportunities(oppData);
        setOpenTrades(tradesData);
        setLoading(false);
      }
    })();

    return () => { cancelled = true; };
  }, [demoUserId]);

  if (loading || !stats) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin w-8 h-8 border-2 border-emerald-500 border-t-transparent rounded-full" />
      </div>
    );
  }

  const kpis = [
    {
      label: 'Capital actuel',
      value: `$${stats.currentCapital.toLocaleString('fr-FR', { minimumFractionDigits: 2 })}`,
      icon: DollarSign,
      color: 'text-emerald-500',
      bg: 'bg-emerald-500/10',
    },
    {
      label: 'Taux de reussite',
      value: `${stats.winRate}%`,
      icon: Target,
      color: stats.winRate >= 50 ? 'text-emerald-500' : 'text-red-500',
      bg: stats.winRate >= 50 ? 'bg-emerald-500/10' : 'bg-red-500/10',
    },
    {
      label: 'P&L net',
      value: `${stats.netProfit >= 0 ? '+' : ''}$${stats.netProfit.toFixed(2)}`,
      icon: stats.netProfit >= 0 ? TrendingUp : TrendingDown,
      color: stats.netProfit >= 0 ? 'text-emerald-500' : 'text-red-500',
      bg: stats.netProfit >= 0 ? 'bg-emerald-500/10' : 'bg-red-500/10',
    },
    {
      label: 'Series en cours',
      value: stats.streakType ? `${stats.streak}x ${stats.streakType}` : '-',
      icon: Flame,
      color: stats.streakType === 'gain' ? 'text-emerald-500' : stats.streakType === 'perte' ? 'text-red-500' : 'text-muted-foreground',
      bg: stats.streakType === 'gain' ? 'bg-emerald-500/10' : stats.streakType === 'perte' ? 'bg-red-500/10' : 'bg-accent/50',
    },
    {
      label: 'Drawdown max',
      value: `$${stats.maxDrawdown.toFixed(2)}`,
      icon: AlertTriangle,
      color: 'text-amber-500',
      bg: 'bg-amber-500/10',
    },
    {
      label: 'Profit Factor',
      value: stats.profitFactor === 999 ? 'Infini' : stats.profitFactor.toFixed(2),
      icon: Zap,
      color: stats.profitFactor >= 1.5 ? 'text-emerald-500' : 'text-amber-500',
      bg: stats.profitFactor >= 1.5 ? 'bg-emerald-500/10' : 'bg-amber-500/10',
    },
    {
      label: 'Resultat du jour',
      value: `${stats.todayResult >= 0 ? '+' : ''}$${stats.todayResult.toFixed(2)}`,
      icon: BarChart3,
      color: stats.todayResult >= 0 ? 'text-emerald-500' : 'text-red-500',
      bg: stats.todayResult >= 0 ? 'bg-emerald-500/10' : 'bg-red-500/10',
    },
    {
      label: 'Positions ouvertes',
      value: String(stats.openTrades),
      icon: Eye,
      color: stats.openTrades > 0 ? 'text-blue-500' : 'text-muted-foreground',
      bg: stats.openTrades > 0 ? 'bg-blue-500/10' : 'bg-accent/50',
    },
  ];

  const chartTooltipStyle = {
    backgroundColor: 'hsl(var(--card))',
    border: '1px solid hsl(var(--border))',
    borderRadius: 8,
    fontSize: 12,
  };

  const recentOpportunities = opportunities.slice(0, 5);

  return (
    <div className="space-y-4">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold">Tableau de bord</h2>
        <p className="text-muted-foreground text-sm mt-1">Vue d'ensemble de votre activite de trading</p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {kpis.map(kpi => {
          const Icon = kpi.icon;
          return (
            <Card key={kpi.label} className="p-3">
              <div className="flex items-center gap-1.5 mb-1">
                <div className={`p-1.5 rounded-lg ${kpi.bg}`}>
                  <Icon className={`w-3.5 h-3.5 ${kpi.color}`} />
                </div>
                <span className="text-[10px] text-muted-foreground truncate">{kpi.label}</span>
              </div>
              <p className={`text-lg font-bold ${kpi.color}`}>{kpi.value}</p>
            </Card>
          );
        })}
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Equity Curve */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Courbe d'equite</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              {stats.equityCurve && stats.equityCurve.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={stats.equityCurve}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="date" tick={{ fontSize: 10 }} stroke="hsl(var(--muted-foreground))" />
                    <YAxis tick={{ fontSize: 10 }} stroke="hsl(var(--muted-foreground))" domain={['auto', 'auto']} />
                    <Tooltip contentStyle={chartTooltipStyle} formatter={(v: number) => [`$${v.toFixed(2)}`, 'Equite']} />
                    <Line type="monotone" dataKey="equity" stroke="#10b981" strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex items-center justify-center h-full text-muted-foreground text-sm">
                  Aucune donnee de courbe d'equite
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Weekly P&L */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">P&L hebdomadaire</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              {stats.weekPnl && stats.weekPnl.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={stats.weekPnl}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="week" tick={{ fontSize: 9 }} stroke="hsl(var(--muted-foreground))" />
                    <YAxis tick={{ fontSize: 10 }} stroke="hsl(var(--muted-foreground))" />
                    <Tooltip contentStyle={chartTooltipStyle} formatter={(v: number) => [`$${v.toFixed(2)}`, 'P&L']} />
                    <ReferenceLine y={0} stroke="hsl(var(--muted-foreground))" />
                    <Bar dataKey="pnl" radius={[4, 4, 0, 0]}>
                      {stats.weekPnl.map((entry, i) => (
                        <Cell key={i} fill={entry.pnl >= 0 ? '#10b981' : '#ef4444'} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex items-center justify-center h-full text-muted-foreground text-sm">
                  Aucune donnee hebdomadaire
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bottom row: Open positions + Opportunities preview */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Open Positions */}
        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium">Positions ouvertes</CardTitle>
              <Button variant="ghost" size="sm" className="text-xs" onClick={() => setCurrentPage('trades')}>
                Voir tout
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {openTrades.length > 0 ? (
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {openTrades.map(trade => (
                  <div key={trade.id} className="flex items-center justify-between p-2 rounded-lg bg-accent/50 hover:bg-accent transition-colors">
                    <div className="flex items-center gap-2">
                      <Badge variant={trade.direction === 'ACHAT' ? 'default' : 'outline'} className={trade.direction === 'ACHAT' ? 'bg-emerald-600 text-white' : 'bg-red-600 text-white'}>
                        {trade.direction}
                      </Badge>
                      <span className="font-mono font-medium text-sm">{trade.asset}</span>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">{trade.entryPrice || '-'}</p>
                      <p className="text-xs text-muted-foreground">{trade.entryDate ? new Date(trade.entryDate).toLocaleDateString('fr-FR') : '-'}</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground text-center py-8">Aucune position ouverte</p>
            )}
          </CardContent>
        </Card>

        {/* Opportunities Preview */}
        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium">Dernieres opportunites</CardTitle>
              <Button variant="ghost" size="sm" className="text-xs" onClick={() => setCurrentPage('opportunities')}>
                Voir tout
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {recentOpportunities.length > 0 ? (
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {recentOpportunities.map(opp => {
                  const sColor = opp.validationScore >= 10 ? 'text-emerald-500' : opp.validationScore >= 7 ? 'text-amber-500' : 'text-red-500';
                  const statusBg = opp.status === 'Validee' ? 'bg-emerald-500' : opp.status === 'En cours' ? 'bg-amber-500' : opp.status === 'Entree' ? 'bg-blue-500' : 'bg-slate-500';
                  return (
                    <div key={opp.id} className="flex items-center justify-between p-2 rounded-lg bg-accent/50 hover:bg-accent transition-colors">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-medium text-sm">{opp.asset}</span>
                        {opp.trendH4 && (
                          <span className={`text-[10px] ${opp.trendH4 === 'Haussier' ? 'text-emerald-500' : opp.trendH4 === 'Baissier' ? 'text-red-500' : 'text-amber-500'}`}>
                            H4 {opp.trendH4}
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`text-sm font-bold ${sColor}`}>{opp.validationScore}/13</span>
                        <Badge className={`${statusBg} text-white text-[10px]`}>{opp.status}</Badge>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground text-center py-8">Aucune opportunite</p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Quick insights */}
      {stats.totalTrades > 0 && (
        <Card>
          <CardContent className="p-4">
            <div className="flex flex-wrap gap-3">
              {stats.weekResult !== 0 && (
                <div className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm ${stats.weekResult > 0 ? 'bg-emerald-500/10 text-emerald-500' : 'bg-red-500/10 text-red-500'}`}>
                  <BarChart3 className="w-4 h-4" />
                  <span>Semaine: {stats.weekResult > 0 ? '+' : ''}${stats.weekResult.toFixed(2)}</span>
                </div>
              )}
              {stats.monthResult !== 0 && (
                <div className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm ${stats.monthResult > 0 ? 'bg-emerald-500/10 text-emerald-500' : 'bg-red-500/10 text-red-500'}`}>
                  <TrendingUp className="w-4 h-4" />
                  <span>Mois: {stats.monthResult > 0 ? '+' : ''}${stats.monthResult.toFixed(2)}</span>
                </div>
              )}
              {stats.planRate < 100 && stats.totalTrades > 0 && (
                <div className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm bg-amber-500/10 text-amber-500">
                  <AlertTriangle className="w-4 h-4" />
                  <span>Plan respecte: {stats.planRate}%</span>
                </div>
              )}
              <div className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm bg-accent/50 text-muted-foreground">
                <Target className="w-4 h-4" />
                <span>Total trades: {stats.totalTrades} ({stats.winCount}G / {stats.lossCount}P)</span>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
