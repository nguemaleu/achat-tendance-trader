'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { RiskCalculatorPanel } from './risk-calculator-panel';

export function RiskCalculatorPage() {
  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-2xl font-bold">Calculateur de risque</h2>
        <p className="text-muted-foreground text-sm mt-1">Calculez la taille de position et le ratio rendement/risque</p>
      </div>
      <RiskCalculatorPanel />
    </div>
  );
}
