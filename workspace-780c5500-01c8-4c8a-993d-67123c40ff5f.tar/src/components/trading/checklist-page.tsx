'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ChecklistPanel, CHECKLIST_KEYS, EXCLUSION_KEYS } from './checklist-panel';

export function ChecklistPage() {
  const [checklist, setChecklist] = useState<Record<string, boolean>>(() => {
    const cl: Record<string, boolean> = {};
    Object.keys(CHECKLIST_KEYS).forEach(k => { cl[k] = false; });
    return cl;
  });
  const [exclusions, setExclusions] = useState<Record<string, boolean>>(() => {
    const ex: Record<string, boolean> = {};
    Object.keys(EXCLUSION_KEYS).forEach(k => { ex[k] = false; });
    return ex;
  });

  function toggle(key: string, value: boolean) {
    setChecklist(prev => ({ ...prev, [key]: value }));
  }
  function toggleExclusion(key: string, value: boolean) {
    setExclusions(prev => ({ ...prev, [key]: value }));
  }
  function reset() {
    const cl: Record<string, boolean> = {};
    Object.keys(CHECKLIST_KEYS).forEach(k => { cl[k] = false; });
    setChecklist(cl);
    const ex: Record<string, boolean> = {};
    Object.keys(EXCLUSION_KEYS).forEach(k => { ex[k] = false; });
    setExclusions(ex);
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Checklist Achat Tendance</h2>
          <p className="text-muted-foreground text-sm mt-1">Vérifiez les conditions par unité de temps (H4, H1, M15) avant une entrée en achat</p>
        </div>
        <button
          onClick={reset}
          className="px-4 py-2 rounded-lg text-sm border border-border hover:bg-accent transition-colors"
        >
          Réinitialiser
        </button>
      </div>
      <Card>
        <CardContent className="p-4">
          <ChecklistPanel
            checklist={checklist}
            exclusions={exclusions}
            onChange={toggle}
            onExclusionChange={toggleExclusion}
          />
        </CardContent>
      </Card>
    </div>
  );
}
