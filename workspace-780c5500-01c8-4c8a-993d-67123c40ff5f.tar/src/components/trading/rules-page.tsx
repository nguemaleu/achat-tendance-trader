'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, TrendingUp, TrendingDown, XCircle, Target, Shield, Clock, Brain, CheckCircle2 } from 'lucide-react';

interface Rule {
  text: string;
  critical?: boolean;
}

interface RuleCategory {
  id: string;
  name: string;
  icon: React.ElementType;
  color: string;
  bg: string;
  rules: Rule[];
}

const CATEGORIES: RuleCategory[] = [
  {
    id: 'tendance',
    name: 'Tendance',
    icon: TrendingUp,
    color: 'text-emerald-500',
    bg: 'bg-emerald-500/10',
    rules: [
      { text: "Le prix doit etre au-dessus de l'EMA 200 sur H4 pour un achat.", critical: true },
      { text: "L'EMA 20 doit etre au-dessus de l'EMA 50 sur H4 (confirmation)." },
      { text: 'Les EMA doivent etre orientees vers le haut sur H4.' },
      { text: "Sommets et creux ascendants sur H1 (structure haussiere).", critical: true },
      { text: "Le prix doit etre au-dessus de l'EMA 200 sur H1.", critical: true },
      { text: "L'EMA 50 doit etre orientee vers le haut sur H1." },
      { text: 'La tendance H4 et H1 doivent etre alignees a la hausse.' },
      { text: "Un desaxement H4/H1 annule le signal d'achat." },
    ],
  },
  {
    id: 'exclusion',
    name: 'Exclusion',
    icon: XCircle,
    color: 'text-red-500',
    bg: 'bg-red-500/10',
    rules: [
      { text: 'La tendance H4 est baissiere - ACHAT INTERDIT.', critical: true },
      { text: 'H4 est haussier mais H1 est clairement baissier - NE PAS ENTRER.', critical: true },
      { text: "Les EMA 20, 50 et 200 sont plates ou entremelees - PAS DE SIGNAL.", critical: true },
      { text: 'Le marche evolue sans direction (range/sideways) - ATTENTE.' },
      { text: 'Le prix monte fortement sans repli (tendance trop avancee) - TROP TARD.' },
      { text: "La bougie de confirmation n'est pas encore clotee - PATIENCE.", critical: true },
      { text: 'Une annonce economique importante est imminente - NE PAS ENTRER.' },
    ],
  },
  {
    id: 'entree',
    name: 'Entree',
    icon: Target,
    color: 'text-blue-500',
    bg: 'bg-blue-500/10',
    rules: [
      { text: "Le prix doit revenir sur un support ou une ancienne resistance devenue support.", critical: true },
      { text: 'Une bougie haussiere de confirmation doit cloter sur M15.', critical: true },
      { text: "Le RSI doit remonter au-dessus de 50." },
      { text: "Le MACD doit donner un signal haussier." },
      { text: "L'entree doit se faire dans la zone de support, pas en casse." },
      { text: 'Ne jamais chasing un prix qui deja depasse la zone.' },
    ],
  },
  {
    id: 'checklist',
    name: 'Checklist',
    icon: CheckCircle2,
    color: 'text-emerald-500',
    bg: 'bg-emerald-500/10',
    rules: [
      { text: 'Le score de validation doit etre superieur a 6 pour envisager une entree.' },
      { text: 'Un score de 10-13/13 indique une configuration forte.' },
      { text: 'Toutes les conditions obligatoires doivent etre validees.' },
      { text: "Meme avec un score eleve, l'absence d'une condition obligatoire empeche la validation.", critical: true },
      { text: 'Les exclusions actives surclassent le score (NE PAS ENTRER).' },
    ],
  },
  {
    id: 'risque',
    name: 'Risque',
    icon: Shield,
    color: 'text-amber-500',
    bg: 'bg-amber-500/10',
    rules: [
      { text: 'Le ratio rendement/risque doit etre au minimum de 2 pour 1.', critical: true },
      { text: 'Le risque maximum par trade est de 1% du capital.' },
      { text: "La limite de pertes quotidienne est de 3% du capital.", critical: true },
      { text: 'Le stop-loss doit etre place sous le support identifie.' },
      { text: 'Ne jamais deplacer le stop-loss dans la direction opposee au trade.' },
      { text: 'La taille de position doit etre calculee avec le calculateur de risque.' },
    ],
  },
  {
    id: 'gestion',
    name: 'Gestion',
    icon: Clock,
    color: 'text-purple-500',
    bg: 'bg-purple-500/10',
    rules: [
      { text: 'Nombre maximum de trades par jour: 5.' },
      { text: "Apres 2 pertes consecutives, arreter de trader pour la journee.", critical: true },
      { text: 'Respecter les sessions de trading preferees.' },
      { text: "Ne pas trader pendant les annonces economiques majeures.", critical: true },
      { text: 'Prendre des pauses regulieres entre les trades.' },
      { text: "Reviser le journal quotidien chaque soir." },
    ],
  },
  {
    id: 'discipline',
    name: 'Discipline',
    icon: Brain,
    color: 'text-cyan-500',
    bg: 'bg-cyan-500/10',
    rules: [
      { text: "Suivre le plan d'analyse sans deviation.", critical: true },
      { text: 'Ne jamais entrer en position sans analyse prealable.' },
      { text: "Eviter le revenge trading apres une perte.", critical: true },
      { text: "Ne pas modifier la taille de position en cours de trade." },
      { text: "Garder un journal de trading a jour." },
      { text: "Accepter les pertes comme faisant partie du processus." },
    ],
  },
  {
    id: 'calendrier',
    name: 'Calendrier',
    icon: Clock,
    color: 'text-orange-500',
    bg: 'bg-orange-500/10',
    rules: [
      { text: 'Verifier le calendrier economique chaque matin.' },
      { text: "Eviter les entrees 30 min avant et apres les annonces majeures.", critical: true },
      { text: "Les sessions optimales: Londres (08h-12h) et New York (14h-17h)." },
      { text: "Le vendredi apres-midi est souvent risquable (fermeture hebdo)." },
      { text: "Les jours feries et weekends: pas de trading." },
    ],
  },
];

export function RulesPage() {
  const [activeCategory, setActiveCategory] = useState('all');

  const filteredCategories = activeCategory === 'all'
    ? CATEGORIES
    : CATEGORIES.filter(c => c.id === activeCategory);

  const totalRules = CATEGORIES.reduce((s, c) => s + c.rules.length, 0);
  const criticalRules = CATEGORIES.reduce((s, c) => s + c.rules.filter(r => r.critical).length, 0);

  return (
    <div className="space-y-4">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold">Regles de trading</h2>
        <p className="text-muted-foreground text-sm mt-1">Cadre strategique et regles de discipline</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        <Card className="p-3">
          <div className="flex items-center gap-1.5 mb-1">
            <Shield className="w-3.5 h-3.5 text-emerald-500" />
            <span className="text-[10px] text-muted-foreground">Total regles</span>
          </div>
          <p className="text-lg font-bold">{totalRules}</p>
        </Card>
        <Card className="p-3">
          <div className="flex items-center gap-1.5 mb-1">
            <AlertTriangle className="w-3.5 h-3.5 text-red-500" />
            <span className="text-[10px] text-muted-foreground">Regles critiques</span>
          </div>
          <p className="text-lg font-bold text-red-500">{criticalRules}</p>
        </Card>
        <Card className="p-3">
          <div className="flex items-center gap-1.5 mb-1">
            <CheckCircle2 className="w-3.5 h-3.5 text-blue-500" />
            <span className="text-[10px] text-muted-foreground">Categories</span>
          </div>
          <p className="text-lg font-bold">{CATEGORIES.length}</p>
        </Card>
      </div>

      {/* Strategy Framework */}
      <Card>
        <CardHeader><CardTitle className="text-base">Cadre strategique - Achat Tendance</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            La strategie est basee sur l&apos;alignement des tendances sur 3 unites de temps. Chaque unite a un role specifique dans la prise de decision.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* H4 */}
            <div className="p-4 rounded-lg border-2 border-emerald-500/30 bg-emerald-500/5">
              <div className="flex items-center gap-2 mb-3">
                <span className="inline-flex items-center justify-center w-10 h-10 rounded-lg bg-emerald-500/20 text-emerald-500 text-sm font-bold">H4</span>
                <div>
                  <h4 className="font-semibold text-sm">Tendance generale</h4>
                  <p className="text-[10px] text-muted-foreground">Filtre principal</p>
                </div>
              </div>
              <ul className="space-y-1.5 text-xs text-muted-foreground">
                <li className="flex items-start gap-1.5"><TrendingUp className="w-3 h-3 mt-0.5 text-emerald-500 shrink-0" /><span>Prix au-dessus EMA 200</span></li>
                <li className="flex items-start gap-1.5"><TrendingUp className="w-3 h-3 mt-0.5 text-emerald-500 shrink-0" /><span>EMA 20 &gt; EMA 50</span></li>
                <li className="flex items-start gap-1.5"><TrendingUp className="w-3 h-3 mt-0.5 text-emerald-500 shrink-0" /><span>EMA orientees vers le haut</span></li>
              </ul>
            </div>

            {/* H1 */}
            <div className="p-4 rounded-lg border-2 border-blue-500/30 bg-blue-500/5">
              <div className="flex items-center gap-2 mb-3">
                <span className="inline-flex items-center justify-center w-10 h-10 rounded-lg bg-blue-500/20 text-blue-500 text-sm font-bold">H1</span>
                <div>
                  <h4 className="font-semibold text-sm">Structure du marche</h4>
                  <p className="text-[10px] text-muted-foreground">Confirmation</p>
                </div>
              </div>
              <ul className="space-y-1.5 text-xs text-muted-foreground">
                <li className="flex items-start gap-1.5"><TrendingUp className="w-3 h-3 mt-0.5 text-blue-500 shrink-0" /><span>Sommets et creux ascendants</span></li>
                <li className="flex items-start gap-1.5"><TrendingUp className="w-3 h-3 mt-0.5 text-blue-500 shrink-0" /><span>Prix au-dessus EMA 200</span></li>
                <li className="flex items-start gap-1.5"><TrendingUp className="w-3 h-3 mt-0.5 text-blue-500 shrink-0" /><span>Alignement avec H4</span></li>
              </ul>
            </div>

            {/* M15 */}
            <div className="p-4 rounded-lg border-2 border-amber-500/30 bg-amber-500/5">
              <div className="flex items-center gap-2 mb-3">
                <span className="inline-flex items-center justify-center w-10 h-10 rounded-lg bg-amber-500/20 text-amber-500 text-sm font-bold">15</span>
                <div>
                  <h4 className="font-semibold text-sm">Point d&apos;entree</h4>
                  <p className="text-[10px] text-muted-foreground">Execution</p>
                </div>
              </div>
              <ul className="space-y-1.5 text-xs text-muted-foreground">
                <li className="flex items-start gap-1.5"><Target className="w-3 h-3 mt-0.5 text-amber-500 shrink-0" /><span>Retour sur support</span></li>
                <li className="flex items-start gap-1.5"><Target className="w-3 h-3 mt-0.5 text-amber-500 shrink-0" /><span>Bougie de confirmation</span></li>
                <li className="flex items-start gap-1.5"><Target className="w-3 h-3 mt-0.5 text-amber-500 shrink-0" /><span>RSI au-dessus de 50</span></li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Exclusion conditions */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <XCircle className="w-5 h-5 text-red-500" />
            Conditions d&apos;exclusion
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-3">Si l&apos;une de ces conditions est active, l&apos;entree est INTERDITE meme si le score est eleve.</p>
          <div className="space-y-2">
            {CATEGORIES.find(c => c.id === 'exclusion')?.rules.map((rule, i) => (
              <div key={i} className={`flex items-start gap-2 p-2.5 rounded-lg border-l-4 ${rule.critical ? 'border-l-red-500 bg-red-500/5' : 'border-l-red-500/30 bg-accent/30'}`}>
                <XCircle className={`w-4 h-4 mt-0.5 shrink-0 ${rule.critical ? 'text-red-500' : 'text-red-500/50'}`} />
                <p className={`text-sm ${rule.critical ? 'text-red-500 font-medium' : 'text-muted-foreground'}`}>{rule.text}</p>
                {rule.critical && <Badge variant="destructive" className="text-[10px] ml-auto shrink-0">CRITIQUE</Badge>}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Category filter */}
      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => setActiveCategory('all')}
          className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${activeCategory === 'all' ? 'bg-emerald-600 text-white' : 'bg-accent/50 text-muted-foreground hover:bg-accent'}`}
        >
          Toutes
        </button>
        {CATEGORIES.map(cat => (
          <button
            key={cat.id}
            onClick={() => setActiveCategory(cat.id)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${activeCategory === cat.id ? 'bg-emerald-600 text-white' : 'bg-accent/50 text-muted-foreground hover:bg-accent'}`}
          >
            {cat.name}
          </button>
        ))}
      </div>

      {/* Rules by category */}
      {filteredCategories.map(cat => {
        const Icon = cat.icon;
        return (
          <Card key={cat.id}>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <div className={`p-1.5 rounded-lg ${cat.bg}`}>
                  <Icon className={`w-4 h-4 ${cat.color}`} />
                </div>
                {cat.name}
                <Badge variant="outline" className="ml-auto text-[10px]">{cat.rules.length} regles</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-1.5">
                {cat.rules.map((rule, i) => (
                  <div key={i} className={`flex items-start gap-3 p-2 rounded-lg border-l-4 ${rule.critical ? `border-l-red-500 bg-red-500/5` : 'border-l-transparent hover:bg-accent/50'}`}>
                    <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5 ${rule.critical ? 'bg-red-500/20 text-red-500' : 'bg-accent text-muted-foreground'}`}>
                      {i + 1}
                    </div>
                    <p className={`text-sm flex-1 ${rule.critical ? 'font-medium' : 'text-muted-foreground'}`}>{rule.text}</p>
                    {rule.critical && (
                      <Badge variant="destructive" className="text-[10px] shrink-0">Critique</Badge>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
