import { create } from 'zustand';

export type Page =
  | 'dashboard'
  | 'opportunities'
  | 'new-analysis'
  | 'checklist'
  | 'risk-calculator'
  | 'trades'
  | 'journal'
  | 'statistics'
  | 'rules'
  | 'settings';

interface AppState {
  currentPage: Page;
  setCurrentPage: (page: Page) => void;
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
  demoUserId: string;
  setDemoUserId: (id: string) => void;
}

export const useAppStore = create<AppState>((set) => ({
  currentPage: 'dashboard',
  setCurrentPage: (page) => set({ currentPage: page }),
  sidebarOpen: false,
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  demoUserId: '',
  setDemoUserId: (id) => set({ demoUserId: id }),
}));

export const API_HEADERS = { 'Content-Type': 'application/json' };

export function apiHeaders(userId: string) {
  return { 'Content-Type': 'application/json', 'x-user-id': userId };
}
