import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

export async function GET(req: NextRequest) {
  try {
    const userId = req.headers.get('x-user-id') || 'demo';
    const status = req.nextUrl.searchParams.get('status');
    const where: Record<string, unknown> = { userId };
    if (status) where.status = status;

    const opportunities = await db.opportunity.findMany({
      where,
      orderBy: { createdAt: 'desc' },
    });
    return NextResponse.json(opportunities);
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch opportunities' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const userId = req.headers.get('x-user-id') || 'demo';
    const body = await req.json();
    const opportunity = await db.opportunity.create({
      data: { ...body, userId },
    });
    return NextResponse.json(opportunity, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to create opportunity' }, { status: 500 });
  }
}
