import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

export async function GET(req: NextRequest) {
  try {
    const userId = req.headers.get('x-user-id') || 'demo';

    const trades = await db.trade.findMany({
      where: { userId, status: { in: ['Fermé en gain', 'Fermé en perte', 'Fermé à l\'équilibre'] } },
      orderBy: { entryDate: 'desc' },
    });

    const openTrades = await db.trade.count({
      where: { userId, status: { in: ['Ouvert', 'Partiellement fermé'] } },
    });

    const settings = await db.userSettings.findUnique({ where: { userId } });
    const currentCapital = settings?.currentCapital || 10000;

    const wins = trades.filter(t => t.status === 'Fermé en gain');
    const losses = trades.filter(t => t.status === 'Fermé en perte');
    const totalTrades = trades.length;
    const winCount = wins.length;
    const lossCount = losses.length;

    const netProfit = trades.reduce((s, t) => s + (t.netResult || 0), 0);
    const grossWin = wins.reduce((s, t) => s + (t.netResult || 0), 0);
    const grossLoss = Math.abs(losses.reduce((s, t) => s + (t.netResult || 0), 0));
    const avgWin = winCount > 0 ? grossWin / winCount : 0;
    const avgLoss = lossCount > 0 ? grossLoss / lossCount : 0;
    const winRate = totalTrades > 0 ? (winCount / totalTrades) * 100 : 0;
    const avgTrade = totalTrades > 0 ? netProfit / totalTrades : 0;
    const profitFactor = grossLoss > 0 ? grossWin / grossLoss : grossWin > 0 ? Infinity : 0;
    const expectancy = totalTrades > 0
      ? (winRate / 100) * avgWin - ((100 - winRate) / 100) * avgLoss
      : 0;

    // Drawdown
    let peak = 0;
    let maxDrawdown = 0;
    let running = 0;
    for (const t of [...trades].reverse()) {
      running += t.netResult || 0;
      if (running > peak) peak = running;
      const dd = peak - running;
      if (dd > maxDrawdown) maxDrawdown = dd;
    }

    // Current streak
    let streak = 0;
    let streakType: 'gain' | 'perte' | null = null;
    for (const t of trades) {
      const isWin = t.status === 'Fermé en gain';
      if (streakType === null) {
        streakType = isWin ? 'gain' : 'perte';
        streak = 1;
      } else if ((streakType === 'gain' && isWin) || (streakType === 'perte' && !isWin)) {
        streak++;
      } else {
        break;
      }
    }

    // Today / week / month
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const weekStart = new Date(todayStart);
    weekStart.setDate(weekStart.getDate() - weekStart.getDay() + 1);
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

    const todayTrades = trades.filter(t => t.exitDate && t.exitDate >= todayStart);
    const weekTrades = trades.filter(t => t.exitDate && t.exitDate >= weekStart);
    const monthTrades = trades.filter(t => t.exitDate && t.exitDate >= monthStart);

    const todayResult = todayTrades.reduce((s, t) => s + (t.netResult || 0), 0);
    const weekResult = weekTrades.reduce((s, t) => s + (t.netResult || 0), 0);
    const monthResult = monthTrades.reduce((s, t) => s + (t.netResult || 0), 0);

    // Plan respect
    const withPlan = trades.filter(t => t.planRespected !== null);
    const planRespected = withPlan.filter(t => t.planRespected === true).length;
    const planRate = withPlan.length > 0 ? (planRespected / withPlan.length) * 100 : 0;

    // Equity curve data
    const equityCurve: { date: string; equity: number }[] = [];
    let eq = settings?.initialCapital || 10000;
    const sortedTrades = [...trades].reverse();
    for (const t of sortedTrades) {
      if (t.netResult) eq += t.netResult;
      equityCurve.push({
        date: t.exitDate ? new Date(t.exitDate).toISOString().split('T')[0] : new Date(t.createdAt).toISOString().split('T')[0],
        equity: Math.round(eq * 100) / 100,
      });
    }

    // Per-asset performance
    const assetPerf: Record<string, { trades: number; wins: number; pnl: number }> = {};
    for (const t of trades) {
      if (!assetPerf[t.asset]) assetPerf[t.asset] = { trades: 0, wins: 0, pnl: 0 };
      assetPerf[t.asset].trades++;
      if (t.status === 'Fermé en gain') assetPerf[t.asset].wins++;
      assetPerf[t.asset].pnl += t.netResult || 0;
    }

    // Per-week P&L for chart
    const weekPnl: { week: string; pnl: number }[] = [];
    const weekMap: Record<string, number> = {};
    for (const t of trades) {
      if (!t.exitDate) continue;
      const d = new Date(t.exitDate);
      const weekNum = getWeekNumber(d);
      const key = `${d.getFullYear()}-S${weekNum}`;
      weekMap[key] = (weekMap[key] || 0) + (t.netResult || 0);
    }
    for (const [week, pnl] of Object.entries(weekMap)) {
      weekPnl.push({ week, pnl: Math.round(pnl * 100) / 100 });
    }

    // Most costly errors
    const errorCosts: Record<string, number> = {};
    for (const t of losses) {
      if (t.mainError) {
        errorCosts[t.mainError] = (errorCosts[t.mainError] || 0) + Math.abs(t.netResult || 0);
      }
    }

    return NextResponse.json({
      currentCapital,
      totalTrades,
      winCount,
      lossCount,
      openTrades,
      winRate: Math.round(winRate * 10) / 10,
      netProfit: Math.round(netProfit * 100) / 100,
      avgWin: Math.round(avgWin * 100) / 100,
      avgLoss: Math.round(avgLoss * 100) / 100,
      avgTrade: Math.round(avgTrade * 100) / 100,
      profitFactor: profitFactor === Infinity ? 999 : Math.round(profitFactor * 100) / 100,
      expectancy: Math.round(expectancy * 100) / 100,
      maxDrawdown: Math.round(maxDrawdown * 100) / 100,
      todayResult: Math.round(todayResult * 100) / 100,
      weekResult: Math.round(weekResult * 100) / 100,
      monthResult: Math.round(monthResult * 100) / 100,
      streak,
      streakType,
      planRate: Math.round(planRate * 10) / 10,
      equityCurve,
      weekPnl,
      assetPerf,
      errorCosts,
      gainLossRatio: avgLoss > 0 ? Math.round((avgWin / avgLoss) * 100) / 100 : 0,
      bestTrade: wins.length > 0 ? Math.max(...wins.map(t => t.netResult || 0)) : 0,
      worstTrade: losses.length > 0 ? Math.min(...losses.map(t => t.netResult || 0)) : 0,
    });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch stats' }, { status: 500 });
  }
}

function getWeekNumber(d: Date): number {
  const date = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  const dayNum = date.getUTCDay() || 7;
  date.setUTCDate(date.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(date.getUTCFullYear(), 0, 1));
  return Math.ceil((((date.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
}
