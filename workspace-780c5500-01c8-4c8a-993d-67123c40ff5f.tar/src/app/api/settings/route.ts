import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

export async function GET(req: NextRequest) {
  try {
    const userId = req.headers.get('x-user-id') || 'demo';
    let settings = await db.userSettings.findUnique({ where: { userId } });
    if (!settings) {
      settings = await db.userSettings.create({
        data: { userId, initialCapital: 10000, currentCapital: 10000 },
      });
    }
    return NextResponse.json(settings);
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch settings' }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const userId = req.headers.get('x-user-id') || 'demo';
    const body = await req.json();
    const settings = await db.userSettings.upsert({
      where: { userId },
      update: body,
      create: { userId, ...body },
    });
    return NextResponse.json(settings);
  } catch (error) {
    return NextResponse.json({ error: 'Failed to update settings' }, { status: 500 });
  }
}
