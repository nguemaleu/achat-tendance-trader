import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

export async function GET(req: NextRequest) {
  try {
    const userId = req.headers.get('x-user-id') || 'demo';
    const status = req.nextUrl.searchParams.get('status');
    const where: Record<string, unknown> = { userId };
    if (status) where.status = status;

    const trades = await db.trade.findMany({
      where,
      orderBy: { entryDate: 'desc' },
    });
    return NextResponse.json(trades);
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch trades' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const userId = req.headers.get('x-user-id') || 'demo';
    const body = await req.json();
    const trade = await db.trade.create({ data: { ...body, userId } });
    return NextResponse.json(trade, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to create trade' }, { status: 500 });
  }
}
