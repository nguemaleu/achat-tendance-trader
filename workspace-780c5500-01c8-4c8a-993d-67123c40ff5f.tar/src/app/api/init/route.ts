import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  try {
    const user = await db.user.findFirst({ where: { email: "demo@achat-tendance.com" } });
    if (!user) {
      return NextResponse.json({ user: null, alerts: [] });
    }
    const alerts = await db.alert.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: "desc" },
    });
    return NextResponse.json({ user: { id: user.id, email: user.email, name: user.name }, alerts });
  } catch (error) {
    console.error("Init API error:", error);
    return NextResponse.json({ user: null, alerts: [] }, { status: 500 });
  }
}
