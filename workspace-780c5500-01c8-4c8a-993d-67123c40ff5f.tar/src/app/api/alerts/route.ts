import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

export async function GET(req: NextRequest) {
  try {
    const userId = req.headers.get('x-user-id') || 'demo';
    const alerts = await db.alert.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
    });
    return NextResponse.json(alerts);
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch alerts' }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const userId = req.headers.get('x-user-id') || 'demo';
    const body = await req.json();
    if (body.markAllRead) {
      await db.alert.updateMany({ where: { userId, isRead: false }, data: { isRead: true } });
      return NextResponse.json({ success: true });
    }
    if (body.id) {
      await db.alert.update({ where: { id: body.id }, data: { isRead: true } });
      return NextResponse.json({ success: true });
    }
    return NextResponse.json({ error: 'Invalid request' }, { status: 400 });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to update alerts' }, { status: 500 });
  }
}
