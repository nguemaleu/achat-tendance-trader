import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  try {
    const userId = req.headers.get('x-user-id') || 'demo';
    const body = await req.json();
    const calc = await db.riskCalculation.create({ data: { ...body, userId } });
    return NextResponse.json(calc, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to save risk calculation' }, { status: 500 });
  }
}

export async function GET(req: NextRequest) {
  try {
    const userId = req.headers.get('x-user-id') || 'demo';
    const calcs = await db.riskCalculation.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });
    return NextResponse.json(calcs);
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch risk calculations' }, { status: 500 });
  }
}
