import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

export async function GET(req: NextRequest) {
  try {
    const userId = req.headers.get('x-user-id') || 'demo';
    const type = req.nextUrl.searchParams.get('type') || 'trades';

    if (type === 'trades') {
      const trades = await db.trade.findMany({
        where: { userId },
        orderBy: { entryDate: 'desc' },
      });

      const headers = ['ID','Actif','Direction','Date Entrée','Date Sortie','Prix Entrée','Stop Loss','TP1','TP2','Prix Sortie','Lots','Capital Avant','Risque %','Résultat Brut','Frais','Résultat Net','Résultat R','Statut','Plan Respecté','Émotion Avant','Erreur Principale','Leçon Apprise'];
      const rows = trades.map(t => [
        t.id, t.asset, t.direction,
        t.entryDate?.toISOString().split('T')[0] || '',
        t.exitDate?.toISOString().split('T')[0] || '',
        t.entryPrice || '', t.initialStopLoss || '',
        t.takeProfit1 || '', t.takeProfit2 || '',
        t.exitPrice || '', t.lotSize || '',
        t.capitalBefore || '', t.riskPercent || '',
        t.grossResult || '', t.fees || '',
        t.netResult || '', t.resultR || '',
        t.status, t.planRespected ? 'Oui' : 'Non',
        t.emotionBefore, t.mainError, t.lessonLearned,
      ].map(v => `"${v}"`).join(','));

      const csv = [headers.join(','), ...rows].join('\n');
      return new NextResponse(csv, {
        headers: {
          'Content-Type': 'text/csv; charset=utf-8',
          'Content-Disposition': 'attachment; filename="trades_export.csv"',
        },
      });
    }

    return NextResponse.json({ error: 'Invalid export type' }, { status: 400 });
  } catch (error) {
    return NextResponse.json({ error: 'Export failed' }, { status: 500 });
  }
}
