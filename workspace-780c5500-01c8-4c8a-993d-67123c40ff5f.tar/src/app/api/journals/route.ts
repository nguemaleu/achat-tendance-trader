import { db } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

export async function GET(req: NextRequest) {
  try {
    const userId = req.headers.get('x-user-id') || 'demo';
    const journals = await db.dailyJournal.findMany({
      where: { userId },
      orderBy: { date: 'desc' },
    });
    return NextResponse.json(journals);
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch journals' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const userId = req.headers.get('x-user-id') || 'demo';
    const body = await req.json();
    const journal = await db.dailyJournal.create({ data: { ...body, userId } });
    return NextResponse.json(journal, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to create journal' }, { status: 500 });
  }
}
