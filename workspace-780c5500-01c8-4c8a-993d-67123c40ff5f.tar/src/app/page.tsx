'use client';

import { useEffect, useState } from 'react';
import { useAppStore } from '@/store/app-store';
import { AppSidebar } from '@/components/trading/app-sidebar';
import { DashboardPage } from '@/components/trading/dashboard-page';
import { OpportunitiesPage } from '@/components/trading/opportunities-page';
import { NewAnalysisPage } from '@/components/trading/new-analysis-page';
import { ChecklistPage } from '@/components/trading/checklist-page';
import { RiskCalculatorPage } from '@/components/trading/risk-calculator-page';
import { TradesPage } from '@/components/trading/trades-page';
import { JournalPage } from '@/components/trading/journal-page';
import { StatisticsPage } from '@/components/trading/statistics-page';
import { RulesPage } from '@/components/trading/rules-page';
import { SettingsPage } from '@/components/trading/settings-page';
import { Button } from '@/components/ui/button';
import { Menu, Bell, TrendingUp } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export default function HomePage() {
  const { currentPage, setSidebarOpen, setDemoUserId, demoUserId } = useAppStore();
  const [alerts, setAlerts] = useState<{ id: string; message: string; isRead: boolean }[]>([]);
  const [showAlerts, setShowAlerts] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    async function init() {
      try {
        const res = await fetch('/api/init');
        const data = await res.json();
        if (data.user) {
          setDemoUserId(data.user.id);
          setAlerts(data.alerts || []);
        }
        setReady(true);
      } catch {
        setReady(true);
      }
    }
    init();
  }, [setDemoUserId]);

  const unreadCount = alerts.filter(a => !a.isRead).length;

  async function markAlertRead(id: string) {
    await fetch('/api/alerts', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id }),
    });
    setAlerts(prev => prev.map(a => a.id === id ? { ...a, isRead: true } : a));
  }

  async function markAllRead() {
    await fetch('/api/alerts', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ markAllRead: true }),
    });
    setAlerts(prev => prev.map(a => ({ ...a, isRead: true })));
  }

  if (!ready || !demoUserId) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="w-12 h-12 rounded-xl bg-emerald-600 flex items-center justify-center mx-auto mb-4">
            <TrendingUp className="w-7 h-7 text-white" />
          </div>
          <h2 className="text-xl font-bold mb-1">Achat Tendance Trader</h2>
          <p className="text-muted-foreground text-sm">Chargement de l'application...</p>
          <div className="mt-4 animate-spin w-6 h-6 border-2 border-emerald-500 border-t-transparent rounded-full mx-auto" />
        </div>
      </div>
    );
  }

  function renderPage() {
    switch (currentPage) {
      case 'dashboard': return <DashboardPage />;
      case 'opportunities': return <OpportunitiesPage />;
      case 'new-analysis': return <NewAnalysisPage />;
      case 'checklist': return <ChecklistPage />;
      case 'risk-calculator': return <RiskCalculatorPage />;
      case 'trades': return <TradesPage />;
      case 'journal': return <JournalPage />;
      case 'statistics': return <StatisticsPage />;
      case 'rules': return <RulesPage />;
      case 'settings': return <SettingsPage />;
      default: return <DashboardPage />;
    }
  }

  return (
    <div className="min-h-screen flex bg-background">
      <AppSidebar />
      <div className="flex-1 flex flex-col min-h-screen lg:ml-0">
        <header className="sticky top-0 z-30 bg-background/80 backdrop-blur-sm border-b border-border px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden"
              onClick={() => setSidebarOpen(true)}
            >
              <Menu className="w-5 h-5" />
            </Button>
            <h1 className="text-sm font-medium text-muted-foreground hidden sm:block">
              Achat Tendance Trader
            </h1>
          </div>
          <div className="flex items-center gap-2">
            <div className="relative">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowAlerts(!showAlerts)}
                className="relative"
              >
                <Bell className="w-4 h-4" />
                {unreadCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-red-500 rounded-full text-[10px] text-white flex items-center justify-center">
                    {unreadCount}
                  </span>
                )}
              </Button>
              {showAlerts && (
                <div className="absolute right-0 top-full mt-1 w-80 bg-card border border-border rounded-lg shadow-lg z-50">
                  <div className="p-3 border-b border-border flex items-center justify-between">
                    <p className="text-sm font-medium">Alertes</p>
                    {unreadCount > 0 && (
                      <button onClick={markAllRead} className="text-xs text-emerald-500 hover:underline">
                        Tout marquer comme lu
                      </button>
                    )}
                  </div>
                  <div className="max-h-64 overflow-y-auto">
                    {alerts.length === 0 ? (
                      <p className="p-4 text-sm text-muted-foreground text-center">Aucune alerte</p>
                    ) : (
                      alerts.slice(0, 10).map(alert => (
                        <button
                          key={alert.id}
                          onClick={() => markAlertRead(alert.id)}
                          className={`w-full text-left p-3 hover:bg-accent/50 border-b border-border/50 transition-colors ${!alert.isRead ? 'bg-emerald-500/5' : ''}`}
                        >
                          <p className={`text-xs ${!alert.isRead ? 'font-medium' : 'text-muted-foreground'}`}>{alert.message}</p>
                        </button>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>
            <Badge variant="outline" className="text-[10px] hidden sm:flex">Mode démo</Badge>
          </div>
        </header>
        <main className="flex-1 p-4 md:p-6 max-w-7xl mx-auto w-full">
          {renderPage()}
        </main>
        <footer className="mt-auto border-t border-border px-4 py-3">
          <p className="text-[10px] text-muted-foreground text-center">
            Outil de planification uniquement. Ne fournit pas de conseil financier. Le trading comporte des risques importants de perte.
          </p>
        </footer>
      </div>
    </div>
  );
}
